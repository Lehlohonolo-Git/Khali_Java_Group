module com.example.learning_management_system_project {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires fontawesomefx;
    requires java.sql;
    requires org.slf4j;
    requires java.desktop;

    opens com.example.learning_management_system_project to javafx.fxml;
    exports com.example.learning_management_system_project;
}