package com.example.learning_management_system_project.models;
public class LecturerCourse {
    private int id;
    private String courseId;
    private String lecturerId;
    private String lecturerName;
    private String courseName;

    public LecturerCourse(int id, String courseId, String lecturerId) {
        this.id = id;
        this.courseId = courseId;
        this.lecturerId = lecturerId;
    }

    public LecturerCourse(int id, String courseId, String lecturerId, String lecturerName, String courseName) {
        this.id = id;
        this.courseId = courseId;
        this.lecturerId = lecturerId;
        this.lecturerName = lecturerName;
        this.courseName = courseName;
    }

    public int getId() {
        return id;
    }

    public String getCourseId() {
        return courseId;
    }

    public String getLecturerId() {
        return lecturerId;
    }

    public String getLecturerName() {
        return lecturerName;
    }

    public String getCourseName() {
        return courseName;
    }
}