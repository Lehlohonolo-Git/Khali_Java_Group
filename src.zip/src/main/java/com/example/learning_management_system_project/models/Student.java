package com.example.learning_management_system_project.models;

public class Student {
    private String studentId;
    private String fullName;

    public Student(String studentId, String fullName) {
        this.studentId = studentId;
        this.fullName = fullName;
    }

    public String getStudentId() { return studentId; }
    public String getFullName() { return fullName; }

    @Override
    public String toString() {
        return fullName + " (" + studentId + ")";
    }
}


