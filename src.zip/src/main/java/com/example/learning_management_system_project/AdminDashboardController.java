package com.example.learning_management_system_project;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.example.learning_management_system_project.DB.DBConnection;

public class AdminDashboardController {

    @FXML private TextField facultyNameField;
    @FXML private TextField programNameField;
    @FXML private ComboBox<String> facultyDropdown;

    @FXML private TextField lecturerNameField;
    @FXML private TextField courseNameField;
    @FXML private ComboBox<String> courseDropdown;

    @FXML private TextField studentNameField;

    private final ObservableList<String> facultyList = FXCollections.observableArrayList();
    private final ObservableList<String> courseList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        loadFaculties();
        loadCourses();
        facultyDropdown.setItems(facultyList);
        courseDropdown.setItems(courseList);
    }

    @FXML
    private void handleAddFaculty() {
        String faculty = facultyNameField.getText();
        if (!faculty.isEmpty()) {
            try (Connection conn = DBConnection.getConnection()) {
                PreparedStatement stmt = conn.prepareStatement("INSERT INTO faculties (faculty_name) VALUES (?)");
                stmt.setString(1, faculty);
                stmt.executeUpdate();
                facultyList.add(faculty);
                facultyNameField.clear();
                showAlert("Success", "Faculty added!");
            } catch (SQLException e) {
                showAlert("Error", "Failed to add faculty: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleAddProgram() {
        String faculty = facultyDropdown.getValue();
        String program = programNameField.getText();
        if (faculty != null && !program.isEmpty()) {
            try (Connection conn = DBConnection.getConnection()) {
                // Get faculty_id by faculty_name
                PreparedStatement getFacultyId = conn.prepareStatement("SELECT faculty_id FROM faculties WHERE faculty_name = ?");
                getFacultyId.setString(1, faculty);
                ResultSet rs = getFacultyId.executeQuery();
                if (rs.next()) {
                    int facultyId = rs.getInt("faculty_id");

                    PreparedStatement stmt = conn.prepareStatement("INSERT INTO programs (program_name, faculty_id) VALUES (?, ?)");
                    stmt.setString(1, program);
                    stmt.setInt(2, facultyId);
                    stmt.executeUpdate();

                    programNameField.clear();
                    showAlert("Success", "Program added under " + faculty + "!");
                } else {
                    showAlert("Error", "Faculty not found.");
                }
            } catch (SQLException e) {
                showAlert("Error", "Failed to add program: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleAssignCourseToLecturer() {
        String lecturer = lecturerNameField.getText();
        String course = courseNameField.getText();

        if (!lecturer.isEmpty() && !course.isEmpty()) {
            try (Connection conn = DBConnection.getConnection()) {
                // Insert or find lecturer
                PreparedStatement insertLecturer = conn.prepareStatement(
                        "INSERT INTO lecturers (lecturer_name) VALUES (?) ON CONFLICT DO NOTHING"
                );
                insertLecturer.setString(1, lecturer);
                insertLecturer.executeUpdate();

                // Get lecturer_id
                PreparedStatement getLecturerId = conn.prepareStatement(
                        "SELECT lecturer_id FROM lecturers WHERE lecturer_name = ?"
                );
                getLecturerId.setString(1, lecturer);
                ResultSet rsLecturer = getLecturerId.executeQuery();

                if (rsLecturer.next()) {
                    int lecturerId = rsLecturer.getInt("lecturer_id");

                    // Insert course (if not exists)
                    PreparedStatement insertCourse = conn.prepareStatement(
                            "INSERT INTO courses (course_name, program_id) " +
                                    "SELECT ?, program_id FROM programs LIMIT 1 ON CONFLICT DO NOTHING"
                    );
                    insertCourse.setString(1, course);
                    insertCourse.executeUpdate();

                    // Get course_id
                    PreparedStatement getCourseId = conn.prepareStatement(
                            "SELECT course_id FROM courses WHERE course_name = ?"
                    );
                    getCourseId.setString(1, course);
                    ResultSet rsCourse = getCourseId.executeQuery();

                    if (rsCourse.next()) {
                        int courseId = rsCourse.getInt("course_id");

                        // Assign course to lecturer
                        PreparedStatement assign = conn.prepareStatement(
                                "INSERT INTO lecturer_courses (lecturer_id, course_id) VALUES (?, ?)"
                        );
                        assign.setInt(1, lecturerId);
                        assign.setInt(2, courseId);
                        assign.executeUpdate();

                        courseList.add(course);
                        lecturerNameField.clear();
                        courseNameField.clear();
                        showAlert("Success", "Course assigned to lecturer!");
                    } else {
                        showAlert("Error", "Failed to get course ID.");
                    }
                } else {
                    showAlert("Error", "Failed to get lecturer ID.");
                }
            } catch (SQLException e) {
                showAlert("Error", "Failed to assign course: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleAddStudent() {
        String student = studentNameField.getText();
        String course = courseDropdown.getValue();

        if (!student.isEmpty() && course != null) {
            try (Connection conn = DBConnection.getConnection()) {
                // Get course_id
                PreparedStatement getCourseId = conn.prepareStatement(
                        "SELECT course_id, program_id FROM courses WHERE course_name = ?"
                );
                getCourseId.setString(1, course);
                ResultSet rs = getCourseId.executeQuery();

                if (rs.next()) {
                    int courseId = rs.getInt("course_id");
                    int programId = rs.getInt("program_id");

                    // Insert student
                    PreparedStatement insertStudent = conn.prepareStatement(
                            "INSERT INTO students (student_name, program_id) VALUES (?, ?)",
                            PreparedStatement.RETURN_GENERATED_KEYS
                    );
                    insertStudent.setString(1, student);
                    insertStudent.setInt(2, programId);
                    insertStudent.executeUpdate();

                    ResultSet generatedKeys = insertStudent.getGeneratedKeys();
                    if (generatedKeys.next()) {
                        int studentId = generatedKeys.getInt(1);

                        // Assign student to course
                        PreparedStatement assign = conn.prepareStatement(
                                "INSERT INTO student_courses (student_id, course_id) VALUES (?, ?)"
                        );
                        assign.setInt(1, studentId);
                        assign.setInt(2, courseId);
                        assign.executeUpdate();

                        studentNameField.clear();
                        showAlert("Success", "Student added and assigned to course!");
                    }
                } else {
                    showAlert("Error", "Course not found.");
                }
            } catch (SQLException e) {
                showAlert("Error", "Failed to add student: " + e.getMessage());
            }
        }
    }

    private void loadFaculties() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT faculty_name FROM faculties");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                facultyList.add(rs.getString("faculty_name"));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load faculties: " + e.getMessage());
        }
    }

    private void loadCourses() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT course_name FROM courses");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                courseList.add(rs.getString("course_name"));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load courses: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.setHeaderText(null);
        alert.showAndWait();
    }
}
