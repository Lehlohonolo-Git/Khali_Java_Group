package com.example.learning_management_system_project;

import com.example.learning_management_system_project.DB.DBConnection;
import javafx.animation.FadeTransition;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.sql.*;
import java.time.format.DateTimeFormatter;

public class LecturerDashboardController {
    private static final Logger logger = LoggerFactory.getLogger(LecturerDashboardController.class);

    @FXML private ComboBox<String> courseComboBox;
    @FXML private Label courseLabel;
    @FXML private TabPane mainTabPane;
    @FXML private VBox streamBox;
    @FXML private ListView<Task> taskList;
    @FXML private ListView<Material> materialList;
    @FXML private ListView<String> studentList;
    @FXML private Button createTaskButton;
    @FXML private Button uploadMaterialButton;

    private final ObservableList<String> courses = FXCollections.observableArrayList();
    private final ObservableList<Task> tasks = FXCollections.observableArrayList();
    private final ObservableList<Material> materials = FXCollections.observableArrayList();
    private final ObservableList<String> students = FXCollections.observableArrayList();
    private final ObservableList<String> taskTypes = FXCollections.observableArrayList("Test1", "MidTerm", "Test2_Group", "FinalExam");
    private int selectedCourseId = -1;
    private int lecturerId;
    private Stage stage;

    private static final int STUDENTS_PER_PAGE = 5;
    @FXML
    private Pagination pagination;

    public void setLecturerId(int lecturerId) {
        this.lecturerId = lecturerId;
        logger.info("Set lecturerId to {} for dashboard", lecturerId);
        loadCourses();
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    public void initialize() {
        courseComboBox.setItems(courses);
        taskList.setItems(tasks);
        materialList.setItems(materials);
        studentList.setItems(students);

        taskList.setCellFactory(param -> new TaskListCell());
        materialList.setCellFactory(param -> new MaterialListCell());
        studentList.setCellFactory(param -> new ListCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty ? null : item);
                setStyle("-fx-padding: 8; -fx-font-size: 14px; -fx-text-fill: #333;");
            }
        });

        for (Button btn : new Button[]{createTaskButton, uploadMaterialButton}) {
            if (btn != null) {
                FadeTransition fade = new FadeTransition(Duration.millis(1000), btn);
                fade.setFromValue(1.0);
                fade.setToValue(0.7);
                fade.setCycleCount(FadeTransition.INDEFINITE);
                fade.setAutoReverse(true);
                fade.play();
            }
        }

        courseComboBox.setOnAction(e -> {
            String selectedCourse = courseComboBox.getValue();
            if (selectedCourse != null) {
                selectedCourseId = Integer.parseInt(selectedCourse.split(":")[0]);
                courseLabel.setText("Selected Course: " + selectedCourse);
                loadStream();
                loadTasks();
                loadMaterials();
                loadStudents();
            } else {
                selectedCourseId = -1;
                courseLabel.setText("Selected Course: None");
                tasks.clear();
                materials.clear();
                students.clear();
                clearStreamBox();
            }
        });
    }

    private void clearStreamBox() {
        streamBox.getChildren().clear();
        Label headerLabel = new Label("Course Stream");
        headerLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 18px; -fx-text-fill: #333;");
        streamBox.getChildren().add(headerLabel);
    }

    private void loadCourses() {
        if (lecturerId == 0) {
            logger.error("Lecturer ID not set. Cannot load courses.");
            showAlert("Error", "User not properly authenticated.");
            return;
        }
        courses.clear();
        String query = """
            SELECT DISTINCT c.course_id, c.course_name
            FROM lecturer_courses lc
            JOIN courses c ON lc.course_id = c.course_id
            WHERE lc.lecturer_id = ?
        """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, lecturerId);
            ResultSet rs = stmt.executeQuery();
            int count = 0;
            while (rs.next()) {
                count++;
                courses.add(rs.getInt("course_id") + ": " + rs.getString("course_name"));
                logger.debug("Loaded course: {} for lecturer_id: {}", rs.getString("course_name"), lecturerId);
            }
            logger.info("Loaded {} courses for lecturer_id: {}", count, lecturerId);
            if (count == 0) {
                showAlert("No Courses", "No courses assigned to this lecturer.");
            }
        } catch (SQLException e) {
            logger.error("Failed to load courses for lecturer_id {}: {}", lecturerId, e.getMessage(), e);
            showAlert("Error", "Unable to load courses: " + e.getMessage());
        }
    }

    private void loadStream() {
        streamBox.getChildren().clear();
        Label headerLabel = new Label("Course Stream");
        headerLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 18px; -fx-text-fill: #333;");
        streamBox.getChildren().add(headerLabel);

        String taskQuery = """
            SELECT task_name, task_type, due_date, weight
            FROM tasks
            WHERE course_id = ? AND lecturer_id = ?
            ORDER BY task_id DESC
        """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(taskQuery)) {
            stmt.setInt(1, selectedCourseId);
            stmt.setInt(2, lecturerId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VBox item = new VBox(5);
                item.setStyle("-fx-background-color: #fff3e0; -fx-border-color: #e0e0e0; -fx-border-radius: 4px; -fx-padding: 10;");
                Label name = new Label("Task: " + rs.getString("task_name"));
                name.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: #333;");
                Label type = new Label("Type: " + rs.getString("task_type"));
                type.setStyle("-fx-font-size: 12px; -fx-text-fill: #555;");
                Label due = new Label("Due: " + (rs.getTimestamp("due_date") != null ? rs.getTimestamp("due_date").toLocalDateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) : "No due date"));
                due.setStyle("-fx-font-size: 12px; -fx-text-fill: #555;");
                Label weight = new Label("Weight: " + String.format("%.0f%%", rs.getDouble("weight") * 100));
                weight.setStyle("-fx-font-size: 12px; -fx-text-fill: #555;");
                item.getChildren().addAll(name, type, due, weight);
                streamBox.getChildren().add(item);
            }
        } catch (SQLException e) {
            logger.error("Failed to load stream tasks for course_id {}: {}", selectedCourseId, e.getMessage(), e);
            showAlert("Error", "Unable to load stream: " + e.getMessage());
        }

        String materialQuery = """
            SELECT material_name
            FROM materials
            WHERE course_id = ? AND lecturer_id = ?
            ORDER BY material_id DESC
        """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(materialQuery)) {
            stmt.setInt(1, selectedCourseId);
            stmt.setInt(2, lecturerId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VBox item = new VBox(5);
                item.setStyle("-fx-background-color: #e8f5e9; -fx-border-color: #e0e0e0; -fx-border-radius: 4px; -fx-padding: 10;");
                Label name = new Label("Material: " + rs.getString("material_name"));
                name.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: #333;");
                item.getChildren().addAll(name);
                streamBox.getChildren().add(item);
            }
        } catch (SQLException e) {
            logger.error("Failed to load stream materials for course_id {}: {}", selectedCourseId, e.getMessage(), e);
            showAlert("Error", "Unable to load stream: " + e.getMessage());
        }
    }

    private void loadTasks() {
        tasks.clear();
        String query = """
            SELECT task_id, task_name, task_type, file_path, due_date, instructions, weight
            FROM tasks
            WHERE course_id = ? AND lecturer_id = ?
        """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, selectedCourseId);
            stmt.setInt(2, lecturerId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                tasks.add(new Task(
                        rs.getInt("task_id"),
                        rs.getString("task_name"),
                        rs.getString("task_type"),
                        rs.getString("file_path"),
                        rs.getTimestamp("due_date"),
                        rs.getString("instructions"),
                        rs.getDouble("weight")
                ));
            }
            logger.info("Loaded {} tasks for course_id: {}, lecturer_id: {}", tasks.size(), selectedCourseId, lecturerId);
        } catch (SQLException e) {
            logger.error("Failed to load tasks for course_id {}: {}", selectedCourseId, e.getMessage(), e);
            showAlert("Error", "Unable to load tasks: " + e.getMessage());
        }
    }

    private void loadMaterials() {
        materials.clear();
        String query = """
            SELECT material_id, material_name, file_path
            FROM materials
            WHERE course_id = ? AND lecturer_id = ?
        """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, selectedCourseId);
            stmt.setInt(2, lecturerId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                materials.add(new Material(
                        rs.getInt("material_id"),
                        rs.getString("material_name"),
                        rs.getString("file_path")
                ));
            }
            logger.info("Loaded {} materials for course_id: {}, lecturer_id: {}", materials.size(), selectedCourseId, lecturerId);
        } catch (SQLException e) {
            logger.error("Failed to load materials for course_id {}: {}", selectedCourseId, e.getMessage(), e);
            showAlert("Error", "Unable to load materials: " + e.getMessage());
        }
    }

    private void loadStudents() {
        students.clear();
        String query = """
            SELECT DISTINCT st.student_id, COALESCE(st.student_name, 'Unknown') AS student_name
            FROM student_courses sc
            JOIN students st ON sc.student_id = st.student_id
            WHERE sc.course_id = ?
        """;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, selectedCourseId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                students.add(rs.getInt("student_id") + ": " + rs.getString("student_name"));
            }

            setupPagination();

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Unable to load students: " + e.getMessage());
        }
    }

    private void setupPagination() {
        int pageCount = (int) Math.ceil((double) students.size() / STUDENTS_PER_PAGE);
        pagination.setPageCount(Math.max(pageCount, 1));
        pagination.setCurrentPageIndex(0);
        pagination.setPageFactory(this::createPage);
    }

    private VBox createPage(int pageIndex) {
        int fromIndex = pageIndex * STUDENTS_PER_PAGE;
        int toIndex = Math.min(fromIndex + STUDENTS_PER_PAGE, students.size());

        ObservableList<String> pageData = FXCollections.observableArrayList(
                students.subList(fromIndex, toIndex)
        );
        studentList.setItems(pageData);

        return new VBox(); // dummy node for pagination
    }

    @FXML
    private void handleCreateTaskClicked() {
        if (selectedCourseId == -1) {
            showAlert("No Course Selected", "Please select a course first.");
            logger.warn("Task creation attempted without course selection: lecturer_id={}", lecturerId);
            return;
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/learning_management_system_project/fxmls/createTask.fxml"));
            if (loader.getLocation() == null) {
                throw new IllegalStateException("createTask.fxml not found in resources");
            }
            Scene createTaskScene = new Scene(loader.load(), 1000, 700);
            CreateTaskController controller = loader.getController();
            Stage createTaskStage = new Stage();
            controller.setCourseId(selectedCourseId);
            controller.setLecturerId(lecturerId);
            controller.setStage(createTaskStage);
            controller.setOnTaskCreated(() -> {
                loadTasks();
                loadStream();
                createTaskStage.close();
            });
            createTaskStage.setScene(createTaskScene);
            createTaskStage.setTitle("Create Task");
            createTaskStage.show();
        } catch (Exception e) {
            logger.error("Failed to open task creation view: lecturer_id={}, error: {}", lecturerId, e.getMessage(), e);
            showAlert("Error", "Unable to open task creation view: " + e.getMessage());
        }
    }

    @FXML
    private void handleUploadMaterial() {
        if (selectedCourseId == -1) {
            showAlert("No Course Selected", "Please select a course first.");
            logger.warn("Material upload attempted without course selection: lecturer_id={}", lecturerId);
            return;
        }
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Upload Learning Material");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Text Files", "*.txt"),
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"),
                new FileChooser.ExtensionFilter("PDF Files", "*.pdf")
        );
        File file = fileChooser.showOpenDialog(stage);
        if (file != null) {
            if (file.length() > 10 * 1024 * 1024) { // 10MB limit
                showAlert("Error", "File size exceeds 10MB limit.");
                logger.warn("File too large for material upload, size: {}", file.length());
                return;
            }
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(
                         "INSERT INTO materials (course_id, lecturer_id, material_name, file_path) VALUES (?, ?, ?, ?)")) {
                stmt.setInt(1, selectedCourseId);
                stmt.setInt(2, lecturerId);
                stmt.setString(3, file.getName());
                stmt.setString(4, file.getAbsolutePath());
                stmt.executeUpdate();
                showAlert("Success", "Material uploaded successfully.");
                logger.info("Uploaded material: {} for course_id: {}, lecturer_id: {}", file.getName(), selectedCourseId, lecturerId);
                loadMaterials();
                loadStream();
            } catch (SQLException e) {
                logger.error("Failed to upload material for course_id {}, lecturer_id {}: {}", selectedCourseId, lecturerId, e.getMessage(), e);
                showAlert("Error", "Material upload failed: " + e.getMessage());
            }
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.initOwner(stage);
        alert.showAndWait();
    }

    private void showSubmissionsDialog(Task task) {
        try {
            String fxmlPath = "/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml";
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            if (loader.getLocation() == null) {
                throw new IllegalStateException("FXML file not found at: " + fxmlPath);
            }
            Scene submissionsScene = new Scene(loader.load(), 1000, 700);
            SubmissionsDialogController controller = loader.getController();
            if (controller == null) {
                throw new IllegalStateException("SubmissionsDialogController not initialized");
            }
            Stage submissionsStage = new Stage();
            controller.setCourseId(selectedCourseId);
            controller.setTaskId(task.getTaskId());
            controller.setLecturerId(lecturerId);
            controller.setStage(submissionsStage);
            controller.setOnMarkAssigned(() -> {
                loadStream();
                loadTasks();
                submissionsStage.close();
            });
            submissionsStage.setScene(submissionsScene);
            submissionsStage.setTitle("Submissions for " + task.getTaskName());
            submissionsStage.show();
            logger.info("Opened submissions dialog for task_id: {}, lecturer_id: {}", task.getTaskId(), lecturerId);
        } catch (Exception e) {
            logger.error("Failed to open submissions dialog: task_id={}, lecturer_id={}, error: {}",
                    task.getTaskId(), lecturerId, e.getMessage(), e);
            showAlert("Error", "Unable to open submissions dialog: " + e.getMessage());
        }
    }

    public static class Task {
        private final int taskId;
        private final SimpleStringProperty taskName;
        private final SimpleStringProperty taskType;
        private final SimpleStringProperty filePath;
        private final Timestamp dueDate;
        private final SimpleStringProperty instructions;
        private final SimpleDoubleProperty weight;

        public Task(int taskId, String taskName, String taskType, String filePath, Timestamp dueDate, String instructions, double weight) {
            this.taskId = taskId;
            this.taskName = new SimpleStringProperty(taskName);
            this.taskType = new SimpleStringProperty(taskType);
            this.filePath = new SimpleStringProperty(filePath != null ? filePath : "No File");
            this.dueDate = dueDate;
            this.instructions = new SimpleStringProperty(instructions != null ? instructions : "No instructions");
            this.weight = new SimpleDoubleProperty(weight);
        }

        public int getTaskId() { return taskId; }
        public String getTaskName() { return taskName.get(); }
        public String getTaskType() { return taskType.get(); }
        public String getFilePath() { return filePath.get(); }
        public Timestamp getDueDate() { return dueDate; }
        public String getInstructions() { return instructions.get(); }
        public double getWeight() { return weight.get(); }
        public String getWeightAsPercentage() { return String.format("%.0f%%", weight.get() * 100); }
    }

    public static class Material {
        private final int materialId;
        private final SimpleStringProperty materialName;
        private final SimpleStringProperty filePath;

        public Material(int materialId, String materialName, String filePath) {
            this.materialId = materialId;
            this.materialName = new SimpleStringProperty(materialName);
            this.filePath = new SimpleStringProperty(filePath != null ? filePath : "No File");
        }

        public int getMaterialId() { return materialId; }
        public String getMaterialName() { return materialName.get(); }
        public String getFilePath() { return filePath.get(); }
    }

    private class TaskListCell extends ListCell<Task> {
        private final HBox hbox = new HBox(10);
        private final Label nameLabel = new Label();
        private final Label typeLabel = new Label();
        private final Label dueLabel = new Label();
        private final Label weightLabel = new Label();
        private final Button viewSubmissionsButton = new Button("View Submissions");

        public TaskListCell() {
            nameLabel.setPrefWidth(150);
            typeLabel.setPrefWidth(100);
            dueLabel.setPrefWidth(120);
            weightLabel.setPrefWidth(80);
            viewSubmissionsButton.setStyle("-fx-background-color: #1a73e8; -fx-text-fill: #ffffff; -fx-font-size: 12px; -fx-padding: 4 8; -fx-border-radius: 4px;");
            hbox.getChildren().addAll(nameLabel, typeLabel, dueLabel, weightLabel, viewSubmissionsButton);

            viewSubmissionsButton.setOnAction(e -> {
                Task task = getItem();
                if (task != null) {
                    showSubmissionsDialog(task);
                }
            });
        }

        @Override
        protected void updateItem(Task item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setGraphic(null);
            } else {
                nameLabel.setText(item.getTaskName());
                nameLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: #333;");
                typeLabel.setText(item.getTaskType());
                typeLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #555;");
                dueLabel.setText(item.getDueDate() != null ? item.getDueDate().toLocalDateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) : "No due date");
                dueLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #555;");
                weightLabel.setText(item.getWeightAsPercentage());
                weightLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #555;");
                setGraphic(hbox);
            }
        }
    }

    private class MaterialListCell extends ListCell<Material> {
        private final HBox hbox = new HBox(10);
        private final Label nameLabel = new Label();

        public MaterialListCell() {
            nameLabel.setPrefWidth(300);
            hbox.getChildren().addAll(nameLabel);
        }

        @Override
        protected void updateItem(Material item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setGraphic(null);
            } else {
                nameLabel.setText(item.getMaterialName());
                nameLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: #333;");
                setGraphic(hbox);
            }
        }
    }

    @FXML
    private void handleExit() {
        System.exit(0);
    }
}