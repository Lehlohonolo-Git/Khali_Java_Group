package com.example.learning_management_system_project;

import com.example.learning_management_system_project.DB.DBConnection;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AddLecturerController {

    @FXML private TextField lecturerNameField;
    @FXML private Button addLecturerButton;
    @FXML private TableView<Lecturer> lecturerTable;
    @FXML private TableColumn<Lecturer, String> lecturerNameColumn;
    @FXML private TableColumn<Lecturer, Void> actionColumn;

    private final ObservableList<Lecturer> lecturerList = FXCollections.observableArrayList();
    private Lecturer selectedLecturer = null;

    @FXML
    public void initialize() {
        lecturerNameColumn.setCellValueFactory(new PropertyValueFactory<>("lecturerName"));
        actionColumn.setCellFactory(param -> new TableCell<>() {
            private final Button updateButton = new Button("Update");
            private final Button deleteButton = new Button("Delete");

            {
                updateButton.setStyle("-fx-background-color: #f1c40f; -fx-text-fill: white; -fx-background-radius: 6; -fx-cursor: hand; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 6, 0, 0, 2); -fx-padding: 6 12;");
                deleteButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-background-radius: 6; -fx-cursor: hand; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.2), 6, 0, 0, 2); -fx-padding: 6 12;");
                updateButton.setOnAction(event -> {
                    Lecturer lecturer = getTableView().getItems().get(getIndex());
                    handleUpdateLecturer(lecturer);
                });
                deleteButton.setOnAction(event -> {
                    Lecturer lecturer = getTableView().getItems().get(getIndex());
                    handleDeleteLecturer(lecturer);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : new HBox(10, updateButton, deleteButton));
            }
        });

        lecturerTable.setItems(lecturerList);
        loadLecturers();
    }

    private void loadLecturers() {
        lecturerList.clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT lecturer_id, lecturer_name FROM lecturers ORDER BY lecturer_name");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                lecturerList.add(new Lecturer(rs.getInt("lecturer_id"), rs.getString("lecturer_name")));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load lecturers: " + e.getMessage());
        }
    }

    @FXML
    private void handleAddLecturer() {
        String lecturerName = lecturerNameField.getText().trim();
        if (lecturerName.isEmpty()) {
            showAlert("Error", "Please enter a lecturer name.");
            return;
        }

        // Validate name: letters, spaces, basic punctuation
        if (!lecturerName.matches("[a-zA-Z\\s,.&-]+")) {
            showAlert("Error", "Lecturer name can only contain letters, spaces, commas, periods, ampersands, or hyphens.");
            return;
        }

        if (lecturerName.length() > 255) {
            showAlert("Error", "Lecturer name must be less than 255 characters.");
            return;
        }

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);

            // Check for duplicate (case-insensitive)
            try (PreparedStatement checkStmt = conn.prepareStatement(
                    "SELECT COUNT(*) FROM lecturers WHERE LOWER(lecturer_name) = LOWER(?)")) {
                checkStmt.setString(1, lecturerName);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next() && rs.getInt(1) > 0 && (selectedLecturer == null || !lecturerName.equalsIgnoreCase(selectedLecturer.getLecturerName()))) {
                    conn.rollback();
                    showAlert("Error", "A lecturer with this name already exists.");
                    return;
                }
            }

            if (selectedLecturer == null) {
                // Add new lecturer
                try (PreparedStatement stmt = conn.prepareStatement(
                        "INSERT INTO lecturers (lecturer_name) VALUES (?)")) {
                    stmt.setString(1, lecturerName);
                    stmt.executeUpdate();
                    showAlert("Success", "Lecturer added successfully!");
                }
            } else {
                // Update existing lecturer
                try (PreparedStatement stmt = conn.prepareStatement(
                        "UPDATE lecturers SET lecturer_name = ? WHERE lecturer_id = ?")) {
                    stmt.setString(1, lecturerName);
                    stmt.setInt(2, selectedLecturer.getLecturerId());
                    stmt.executeUpdate();
                    showAlert("Success", "Lecturer updated successfully!");
                    selectedLecturer = null;
                    addLecturerButton.setText("Add Lecturer");
                }
            }

            conn.commit();
            lecturerNameField.clear();
            loadLecturers();
        } catch (SQLException e) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
            if ("23505".equals(e.getSQLState())) {
                showAlert("Error", "A lecturer with this name already exists.");
            } else if ("23503".equals(e.getSQLState())) {
                showAlert("Error", "Cannot save lecturer due to a database constraint: " + e.getMessage());
            } else {
                showAlert("Error", "Failed to save lecturer: " + e.getMessage());
            }
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException closeEx) {
                    closeEx.printStackTrace();
                }
            }
            selectedLecturer = null;
            addLecturerButton.setText("Add Lecturer");
        }
    }

    private void handleUpdateLecturer(Lecturer lecturer) {
        selectedLecturer = lecturer;
        lecturerNameField.setText(lecturer.getLecturerName());
        addLecturerButton.setText("Save Changes");
    }

    private void handleDeleteLecturer(Lecturer lecturer) {
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION,
                "Are you sure you want to delete " + lecturer.getLecturerName() + "?", ButtonType.YES, ButtonType.NO);
        confirmation.setHeaderText(null);
        confirmation.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                try (Connection conn = DBConnection.getConnection();
                     PreparedStatement stmt = conn.prepareStatement("DELETE FROM lecturers WHERE lecturer_id = ?")) {
                    stmt.setInt(1, lecturer.getLecturerId());
                    stmt.executeUpdate();
                    loadLecturers();
                    showAlert("Success", "Lecturer deleted successfully!");
                } catch (SQLException e) {
                    if ("23503".equals(e.getSQLState())) {
                        showAlert("Error", "Cannot delete lecturer because they are assigned to courses or other records.");
                    } else {
                        showAlert("Error", "Failed to delete lecturer: " + e.getMessage());
                    }
                }
            }
        });
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static class Lecturer {
        private final SimpleIntegerProperty lecturerId;
        private final SimpleStringProperty lecturerName;

        public Lecturer(int id, String name) {
            this.lecturerId = new SimpleIntegerProperty(id);
            this.lecturerName = new SimpleStringProperty(name);
        }

        public int getLecturerId() {
            return lecturerId.get();
        }

        public String getLecturerName() {
            return lecturerName.get();
        }
    }

    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    private Stage getStageFromEvent(ActionEvent event) {
        Object source = event.getSource();
        if (source instanceof Node) {
            return (Stage) ((Node) source).getScene().getWindow();
        } else if (source instanceof MenuItem) {
            return (Stage) ((MenuItem) source).getParentPopup().getOwnerWindow();
        }
        throw new IllegalStateException("Cannot determine Stage from event source.");
    }

    private void loadFXML(String fxmlPath, String title, ActionEvent event) throws IOException {
        URL resource = getClass().getResource(fxmlPath);
        if (resource == null) {
            throw new IllegalStateException("Cannot find FXML file at: " + fxmlPath);
        }
        Stage currentStage = (stage != null) ? stage : getStageFromEvent(event);
        FXMLLoader loader = new FXMLLoader(resource);
        Scene scene = new Scene(loader.load(), 900, 600);
        currentStage.setScene(scene);
        currentStage.setTitle(title);

        Object controller = loader.getController();
        if (controller != null) {
            try {
                Method setStageMethod = controller.getClass().getMethod("setStage", Stage.class);
                setStageMethod.invoke(controller, currentStage);
            } catch (NoSuchMethodException ignored) {
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        currentStage.show();
    }

    @FXML
    private void handleViewStudents(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewStudents.fxml", "View Students", event);
    }

    @FXML
    private void handleProgressReport(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/Reports.fxml", "Reports", event);
    }

    @FXML
    private void handleExportReport(ActionEvent event) {
        showAlert("Info", "Export report functionality not implemented.");
    }

    @FXML
    private void handleAbout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AboutUs.fxml", "About Us", event);
    }

    @FXML
    private void handleDocumentation(ActionEvent event) {
        showAlert("Info", "Documentation not available.");
    }

    @FXML
    private void handleAddCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddCourse.fxml", "Add Course", event);
    }

    @FXML
    private void handleExit(ActionEvent event) {
        getStageFromEvent(event).close();
    }

    @FXML
    private void handleHome(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/Home.fxml", "Home", event);
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        loadLecturers();
    }

    @FXML
    private void handleAddStudent(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddStudent.fxml", "Add Student", event);
    }

    @FXML
    private void handleViewStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Report", event);
    }

    @FXML
    private void handleAssignCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AdminAssignCoursesView.fxml", "Assign Courses", event);
    }

    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/Login.fxml", "Login", event);
    }

    @FXML
    private void handleAddLecturer(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddLecturer.fxml", "Add Lecturer", event);
    }

    @FXML
    private void handleViewLecturers(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewLecturers.fxml", "View Lecturers", event);
    }

    @FXML
    private void handleAddFaculty(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddFaculty.fxml", "Add Faculty", event);
    }

    @FXML
    private void handleViewFaculties(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewFaculties.fxml", "View Faculties", event);
    }
}