package com.example.learning_management_system_project;

import javafx.beans.property.SimpleStringProperty;

import java.sql.Timestamp;

public class Material {
    private final int materialId;
    private final SimpleStringProperty materialName;
    private final SimpleStringProperty filePath;
    private final Timestamp uploadDate;

    public Material(int materialId, String materialName, String filePath, Timestamp uploadDate) {
        this.materialId = materialId;
        this.materialName = new SimpleStringProperty(materialName);
        this.filePath = new SimpleStringProperty(filePath != null ? filePath : "No File");
        this.uploadDate = uploadDate;
    }

    public int getMaterialId() { return materialId; }
    public String getMaterialName() { return materialName.get(); }
    public String getFilePath() { return filePath.get(); }
    public Timestamp getUploadDate() { return uploadDate; }
}