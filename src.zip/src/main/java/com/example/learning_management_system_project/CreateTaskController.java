package com.example.learning_management_system_project;

import com.example.learning_management_system_project.DB.DBConnection;
import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CreateTaskController {
    private static final Logger logger = LoggerFactory.getLogger(CreateTaskController.class);

    @FXML private TextField taskNameField;
    @FXML private ComboBox<String> taskTypeComboBox;
    @FXML private DatePicker dueDatePicker;
    @FXML private TextArea instructionsArea;
    @FXML private TextField weightField;
    @FXML private Button uploadFileButton;
    @FXML private Label fileLabel;
    @FXML private Button createTaskButton;
    @FXML private Button cancelButton;

    private final ObservableList<String> taskTypes = FXCollections.observableArrayList("Test1", "MidTerm", "Test2_Group", "FinalExam");
    private int courseId;
    private int lecturerId;
    private Stage stage;
    private File selectedFile;
    private Runnable onTaskCreated;

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public void setLecturerId(int lecturerId) {
        this.lecturerId = lecturerId;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void setOnTaskCreated(Runnable onTaskCreated) {
        this.onTaskCreated = onTaskCreated;
    }

    @FXML
    private void initialize() {
        taskTypeComboBox.setItems(taskTypes);

        FadeTransition fade = new FadeTransition(Duration.millis(1000), createTaskButton);
        fade.setFromValue(1.0);
        fade.setToValue(0.7);
        fade.setCycleCount(FadeTransition.INDEFINITE);
        fade.setAutoReverse(true);
        fade.play();

        FadeTransition cancelFade = new FadeTransition(Duration.millis(1000), cancelButton);
        cancelFade.setFromValue(1.0);
        cancelFade.setToValue(0.7);
        cancelFade.setCycleCount(FadeTransition.INDEFINITE);
        cancelFade.setAutoReverse(true);
        cancelFade.play();
    }

    @FXML
    private void handleUploadFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Task File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Text Files", "*.txt"),
                new FileChooser.ExtensionFilter("PDF Files", "*.pdf"),
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
        );
        selectedFile = fileChooser.showOpenDialog(stage);
        if (selectedFile != null) {
            fileLabel.setText(selectedFile.getName());
            logger.info("Selected file: {} for task creation, lecturer_id: {}", selectedFile.getName(), lecturerId);
        }
    }

    @FXML
    private void handleCreateTask() {
        String taskName = taskNameField.getText().trim();
        String taskType = taskTypeComboBox.getValue();
        LocalDateTime dueDate = dueDatePicker.getValue() != null ? dueDatePicker.getValue().atStartOfDay() : null;
        String instructions = instructionsArea.getText().trim();
        double weight;

        if (taskName.isEmpty() || taskType == null) {
            showAlert("Error", "Task name and type are required.");
            return;
        }

        try {
            weight = Double.parseDouble(weightField.getText().trim());
            if (weight < 0 || weight > 1) {
                throw new NumberFormatException("Weight must be between 0 and 1.");
            }
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid weight: " + e.getMessage());
            return;
        }

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO tasks (course_id, lecturer_id, task_name, task_type, file_path, due_date, instructions, weight, upload_date) " +
                             "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
            stmt.setInt(1, courseId);
            stmt.setInt(2, lecturerId);
            stmt.setString(3, taskName);
            stmt.setString(4, taskType);
            stmt.setString(5, selectedFile != null ? selectedFile.getAbsolutePath() : null);
            stmt.setTimestamp(6, dueDate != null ? Timestamp.valueOf(dueDate) : null);
            stmt.setString(7, instructions.isEmpty() ? null : instructions);
            stmt.setDouble(8, weight);
            stmt.setTimestamp(9, Timestamp.valueOf(LocalDateTime.now()));
            stmt.executeUpdate();

            logger.info("Task created: {} for course_id: {}, lecturer_id: {}", taskName, courseId, lecturerId);
            showAlert("Success", "Task created successfully!");
            if (onTaskCreated != null) {
                onTaskCreated.run();
            }
            stage.close();
        } catch (SQLException e) {
            logger.error("Failed to create task for course_id {}, lecturer_id {}: {}", courseId, lecturerId, e.getMessage(), e);
            showAlert("Error", "Task creation failed: " + e.getMessage());
        }
    }

    @FXML
    private void handleCancel() {
        stage.close();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.initOwner(stage);
        alert.showAndWait();
    }
}