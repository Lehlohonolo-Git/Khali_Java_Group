package com.example.learning_management_system_project;

import com.example.learning_management_system_project.DB.DBConnection;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.scene.control.cell.PropertyValueFactory;
import com.example.learning_management_system_project.models.Faculty;
import com.example.learning_management_system_project.models.Program;
import com.example.learning_management_system_project.models.Student;
import com.example.learning_management_system_project.models.LecturerCourse;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleStringProperty;


import javafx.beans.property.SimpleBooleanProperty;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;


public class AdminAssignCoursesController {

    @FXML private ComboBox<Faculty> facultyComboBox;
    @FXML private ComboBox<Program> programComboBox;
    @FXML private ComboBox<Student> studentComboBox;

    @FXML private ListView<String> courseSelectionListView;

    @FXML private TableView<LecturerCourse> lecturerCourseTable;
    @FXML private TableColumn<LecturerCourse, Integer> lcIdColumn;
    @FXML private TableColumn<LecturerCourse, String> lecturerIdColumn;
    @FXML private TableColumn<LecturerCourse, String> lecturerNameColumn;
    @FXML private TableColumn<LecturerCourse, String> courseIdColumn;
    @FXML private TableColumn<LecturerCourse, String> courseNameColumn;

    @FXML private Button assignCoursesButton;
    @FXML private Button addLecturerCourseButton;

    @FXML private TextField courseIdField;       // Optional, if you want to input courseId manually
    @FXML private TextField lecturerIdField;     // Optional, if you want to input lecturerId manually
    private final ObservableList<String> courseSelectionList = FXCollections.observableArrayList();
    private final Map<String, Boolean> selectedCourses = new HashMap<>();

    private ObservableList<Faculty> facultyList = FXCollections.observableArrayList();
    private ObservableList<Program> programList = FXCollections.observableArrayList();
    private ObservableList<Student> studentList = FXCollections.observableArrayList();
    private ObservableList<LecturerCourse> lecturerCourseList = FXCollections.observableArrayList();


    @FXML
    public void initialize() {
        loadFaculties();
        loadPrograms();
        loadStudents();
        setupTable();
        loadLecturerCourses();
        setupCourseSelectionList();
    }

    private void loadFaculties() {
        facultyList.clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM faculties");
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                facultyList.add(new Faculty(rs.getInt("faculty_id"), rs.getString("faculty_name")));
            }
            facultyComboBox.setItems(facultyList);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadPrograms() {
        programList.clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM programs");
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                programList.add(new Program(rs.getInt("program_id"), rs.getString("program_name")));
            }
            programComboBox.setItems(programList);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadStudents() {
        studentList.clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM students");
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int studentIdFromDb = rs.getInt("student_id");
                String studentName = rs.getString("student_name");
                studentList.add(new Student(String.valueOf(studentIdFromDb), studentName));
            }
            studentComboBox.setItems(studentList);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void setupTable() {
        lcIdColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getId()));
        lecturerIdColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getLecturerId()));
        lecturerNameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getLecturerName()));
        courseIdColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getCourseId()));
        courseNameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getCourseName()));
// Make sure model has this property

        lecturerCourseTable.setItems(lecturerCourseList);
    }

    private void loadLecturerCourses() {
        lecturerCourseList.clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT lc.id, lc.course_id, lc.lecturer_id, l.lecturer_name, c.course_name " +
                             "FROM lecturer_courses lc " +
                             "JOIN lecturers l ON lc.lecturer_id = l.lecturer_id " +
                             "JOIN courses c ON lc.course_id = c.course_id"
             );
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                lecturerCourseList.add(new LecturerCourse(
                        rs.getInt("id"),
                        rs.getString("course_id"),
                        rs.getString("lecturer_id"),
                        rs.getString("lecturer_name"),
                        rs.getString("course_name")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private void setupCourseSelectionList() {
        courseSelectionList.clear();
        selectedCourses.clear();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT course_name FROM courses");
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String courseName = rs.getString("course_name");
                courseSelectionList.add(courseName);
                selectedCourses.put(courseName, false); // ✅ Initialize
            }

            courseSelectionListView.setItems(courseSelectionList);

            courseSelectionListView.setCellFactory(CheckBoxListCell.forListView(new Callback<String, javafx.beans.value.ObservableValue<Boolean>>() {
                @Override
                public javafx.beans.value.ObservableValue<Boolean> call(String item) {
                    return new javafx.beans.property.SimpleBooleanProperty(selectedCourses.get(item)) {
                        @Override
                        public void set(boolean newValue) {
                            super.set(newValue);
                            selectedCourses.put(item, newValue); // ✅ Update selection state
                        }
                    };
                }
            }));

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void addLecturerCourse() {
        // You can implement dialog/input to add lecturer and course association
        showAlert("Not Implemented", "Please implement adding LecturerCourse.");
    }

    @FXML
    public void handleAssignCourses(ActionEvent actionEvent) {
        Student selectedStudent = studentComboBox.getSelectionModel().getSelectedItem();
        ObservableList<String> selectedCourses = courseSelectionListView.getSelectionModel().getSelectedItems();

        if (selectedStudent == null) {
            showAlert("Validation Error", "Please select a student.");
            return;
        }

        if (selectedCourses.isEmpty()) {
            showAlert("Validation Error", "Please select at least one course to assign.");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            for (String courseName : selectedCourses) {
                // Get course_id from course_name
                PreparedStatement getCourseIdStmt = conn.prepareStatement("SELECT course_id FROM courses WHERE course_name = ?");
                getCourseIdStmt.setString(1, courseName);
                ResultSet rs = getCourseIdStmt.executeQuery();
                if (rs.next()) {
                    int courseId = rs.getInt("course_id");
                    // Insert into student_courses
                    PreparedStatement insertStmt = conn.prepareStatement(
                            "INSERT INTO student_courses (student_id, course_id, lecturer_id) VALUES (?, ?, ?)"
                    );
                    insertStmt.setInt(1, Integer.parseInt(selectedStudent.getStudentId()));
                    insertStmt.setInt(2, courseId);
                    // Optionally, assign a lecturer if needed
                    insertStmt.setNull(3, java.sql.Types.INTEGER);
                    insertStmt.executeUpdate();
                }
            }
            showAlert("Success", "Courses assigned successfully to " + selectedStudent.getStudentId());

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to assign courses.");
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
    @FXML
    private void handleViewStudents(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/StudentDashboard.fxml", "Student Dashboard", event);
    }

    @FXML
    private void handleProgressReport(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/Reports.fxml", "Reports", event);
    }

    @FXML
    private void handleExportReport(ActionEvent event) {
        System.out.println("Export Report clicked.");
        // Implement PDF or CSV export logic
    }

    @FXML
    private void handleAbout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AboutUs.fxml", "About Us", event);
    }

    @FXML
    private void handleDocumentation(ActionEvent event) {
        System.out.println("Documentation clicked.");
        // Open documentation or help file
    }

    @FXML
    private void handleViewCourses(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AdminDashboard.fxml", "Admin Dashboard", event);
    }

    @FXML
    private void handleExit(ActionEvent event) {
        getStageFromEvent(event).close();
    }

    @FXML
    private void handleHome(ActionEvent event) throws IOException {
        URL resource = getClass().getResource("/com/example/learning_management_system_project/fxmls/Home.fxml");
        if (resource == null) {
            throw new IllegalStateException("Cannot find FXML file at: /com/example/learning_management_system_project/fxmls/Home.fxml");
        }
        FXMLLoader loader = new FXMLLoader(resource);
        Scene scene = ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow().getScene();
        scene.setRoot(loader.load());
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        System.out.println("Refresh clicked.");
        // Refresh current view if needed
    }

    @FXML
    private void handleAddCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/createTask.fxml", "Create Task", event);
    }

    @FXML
    private void handleAddStudent(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/StudentDashboard.fxml", "Student Dashboard", event);
    }

    @FXML
    private void handleViewStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleAssignCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AdminAssignCoursesView.fxml", "Assign Courses", event);
    }

    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/Login.fxml", "Login", event);
    }
    private void loadFXML(String fxmlPath, String title, ActionEvent event) throws IOException {
        URL resource = getClass().getResource(fxmlPath);
        if (resource == null) {
            throw new IllegalStateException("Cannot find FXML file at: " + fxmlPath);
        }
        Stage currentStage = (stage != null) ? stage : getStageFromEvent(event);
        FXMLLoader loader = new FXMLLoader(resource);
        Scene scene = new Scene(loader.load(), 900, 500);
        currentStage.setScene(scene);
        currentStage.setTitle(title);

        Object controller = loader.getController();
        if (controller != null) {
            try {
                Method setStageMethod = controller.getClass().getMethod("setStage", Stage.class);
                setStageMethod.invoke(controller, currentStage);
            } catch (NoSuchMethodException e) {
                // Optional stage setting method is absent — safe to ignore.
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        currentStage.show();
    }
    private Stage getStageFromEvent(ActionEvent event) {
        Object source = event.getSource();
        if (source instanceof Node) {
            return (Stage) ((Node) source).getScene().getWindow();
        } else if (source instanceof MenuItem) {
            return (Stage) MenuItem.class.cast(source).getParentPopup().getOwnerWindow();
        }
        throw new IllegalStateException("Cannot determine Stage from event source.");
    }

    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }
}