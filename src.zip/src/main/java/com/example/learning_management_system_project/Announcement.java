package com.example.learning_management_system_project;

import java.sql.Timestamp;

public class Announcement {
    private final int announcementId;
    private final String content;
    private final Timestamp postedDate;

    public Announcement(int announcementId, String content, Timestamp postedDate) {
        this.announcementId = announcementId;
        this.content = content;
        this.postedDate = postedDate;
    }

    public int getAnnouncementId() { return announcementId; }
    public String getContent() { return content; }
    public Timestamp getPostedDate() { return postedDate; }
}