package com.example.learning_management_system_project;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.sql.*;

public class ReportsController {

    @FXML private PieChart pieChart;
    @FXML private BarChart<String, Number> barChart;
    @FXML private CategoryAxis xAxis;
    @FXML private NumberAxis yAxis;

    @FXML
    public void initialize() {
        loadChartData();
    }

    private void loadChartData() {
        String url = "jdbc:postgresql://localhost:5433/learning_management_system_project";
        String user = "postgres";  // Replace with your actual DB username
        String password = "masilo57372666";  // Replace with your actual DB password

        String query = """
            SELECT s.student_id, st.student_name, MAX(s.mark) AS mark
            FROM submissions s
            JOIN students st ON s.student_id = st.student_id
            WHERE s.mark IS NOT NULL
            GROUP BY s.student_id, st.student_name;
        """;

        ObservableList<PieChart.Data> pieData = FXCollections.observableArrayList();
        XYChart.Series<String, Number> barSeries = new XYChart.Series<>();
        barSeries.setName("Student Marks");

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                String studentName = rs.getString("student_name");
                int mark = rs.getInt("mark");

                pieData.add(new PieChart.Data(studentName, mark));
                barSeries.getData().add(new XYChart.Data<>(studentName, mark));
            }

            pieChart.setData(pieData);
            barChart.getData().clear();
            barChart.getData().add(barSeries);

        } catch (SQLException e) {
            System.err.println("Error loading chart data:");
            e.printStackTrace();
        }
    }
    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    private Stage getStageFromEvent(ActionEvent event) {
        Object source = event.getSource();
        if (source instanceof Node) {
            return (Stage) ((Node) source).getScene().getWindow();
        } else if (source instanceof MenuItem) {
            return (Stage) MenuItem.class.cast(source).getParentPopup().getOwnerWindow();
        }
        throw new IllegalStateException("Cannot determine Stage from event source.");
    }

    private void loadFXML(String fxmlPath, String title, ActionEvent event) throws IOException {
        URL resource = getClass().getResource(fxmlPath);
        if (resource == null) {
            throw new IllegalStateException("Cannot find FXML file at: " + fxmlPath);
        }
        Stage currentStage = (stage != null) ? stage : getStageFromEvent(event);
        FXMLLoader loader = new FXMLLoader(resource);
        Scene scene = new Scene(loader.load(), 900, 500);
        currentStage.setScene(scene);
        currentStage.setTitle(title);

        Object controller = loader.getController();
        if (controller != null) {
            try {
                Method setStageMethod = controller.getClass().getMethod("setStage", Stage.class);
                setStageMethod.invoke(controller, currentStage);
            } catch (NoSuchMethodException e) {
                // Optional stage setting method is absent — safe to ignore.
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        currentStage.show();
    }

    @FXML
    private void handleViewStudents(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewStudents.fxml", "Student Dashboard", event);
    }

    @FXML
    private void handleProgressReport(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/Reports.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleExportReport(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/Reports.fxml", "Reports", event);
    }

    @FXML
    private void handleAbout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AboutUs.fxml", "About Us", event);
    }

    @FXML
    private void handleDocumentation(ActionEvent event) {
        System.out.println("Documentation clicked.");
    }

    @FXML
    private void handleViewCourses(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewCourses.fxml", "View Courses", event);
    }

    @FXML
    private void handleExit(ActionEvent event) {
        getStageFromEvent(event).close();
    }

    @FXML
    private void handleHome(ActionEvent event) throws IOException {
        URL resource = getClass().getResource("/com/example/learning_management_system_project/fxmls/Home.fxml");
        if (resource == null) {
            throw new IllegalStateException("Cannot find FXML file at: /com/example/learning_management_system_project/fxmls/Home.fxml");
        }
        FXMLLoader loader = new FXMLLoader(resource);
        Scene scene = ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow().getScene();
        scene.setRoot(loader.load());
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        System.out.println("Refresh clicked.");
    }

    @FXML
    private void handleAddCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddCourse.fxml", "Add Course", event);
    }

    @FXML
    private void handleAddStudent(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddStudent.fxml", "Student Dashboard", event);
    }

    @FXML
    private void handleViewStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleAssignCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AdminAssignCoursesView.fxml", "Assign Courses", event);
    }

    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/Login.fxml", "Login", event);
    }

    @FXML
    private void handleAddLecturer(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddLecturer.fxml", "Add Lecturer", event);
    }

    @FXML
    private void handleViewLecturers(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewLecturers.fxml", "View Lecturers", event);
    }

    @FXML
    private void handleAddFaculty(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddFaculty.fxml", "Add Faculty", event);
    }

    @FXML
    private void handleViewFaculties(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewFaculties.fxml", "View Faculties", event);
    }
}
