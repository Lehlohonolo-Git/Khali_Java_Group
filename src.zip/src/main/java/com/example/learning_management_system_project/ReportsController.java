package com.example.learning_management_system_project;



import com.example.learning_management_system_project.DB.DBConnection;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ReportsController {
    private static final Logger logger = LoggerFactory.getLogger(ReportsController.class);

    @FXML private ComboBox<String> courseComboBox;
    @FXML private Label courseLabel;
    @FXML private TableView<SubmissionReport> reportTable;
    @FXML private TableColumn<SubmissionReport, Number> studentIdColumn;
    @FXML private TableColumn<SubmissionReport, String> studentNameColumn;
    @FXML private TableColumn<SubmissionReport, String> markColumn;

    private final ObservableList<String> courses = FXCollections.observableArrayList();
    private final ObservableList<SubmissionReport> submissions = FXCollections.observableArrayList();
    private int selectedCourseId = -1;
    private int lecturerId;
    private Stage stage;

    public void setLecturerId(int lecturerId) {
        this.lecturerId = lecturerId;
        logger.info("Set lecturerId to {} for reports", lecturerId);
        loadCourses();
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    public void initialize() {
        courseComboBox.setItems(courses);
        reportTable.setItems(submissions);

        // Configure TableView columns
        studentIdColumn.setCellValueFactory(cellData -> cellData.getValue().studentIdProperty());
        studentNameColumn.setCellValueFactory(cellData -> cellData.getValue().studentNameProperty());
        markColumn.setCellValueFactory(cellData -> cellData.getValue().markProperty());

        courseComboBox.setOnAction(e -> {
            String selectedCourse = courseComboBox.getValue();
            if (selectedCourse != null) {
                selectedCourseId = Integer.parseInt(selectedCourse.split(":")[0]);
                courseLabel.setText("Selected Course: " + selectedCourse);
                loadSubmissions();
            } else {
                selectedCourseId = -1;
                courseLabel.setText("Selected Course: None");
                submissions.clear();
            }
        });
    }

    private void loadCourses() {
        if (lecturerId == 0) {
            logger.error("Lecturer ID not set. Cannot load courses.");
            showAlert("Error", "User not properly authenticated.");
            return;
        }
        courses.clear();
        String query = """
            SELECT DISTINCT c.course_id, c.course_name
            FROM lecturer_courses lc
            JOIN courses c ON lc.course_id = c.course_id
            WHERE lc.lecturer_id = ?
        """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, lecturerId);
            ResultSet rs = stmt.executeQuery();
            int count = 0;
            while (rs.next()) {
                count++;
                courses.add(rs.getInt("course_id") + ": " + rs.getString("course_name"));
                logger.debug("Loaded course: {} for lecturer_id: {}", rs.getString("course_name"), lecturerId);
            }
            logger.info("Loaded {} courses for lecturer_id: {}", count, lecturerId);
            if (count == 0) {
                showAlert("No Courses", "No courses assigned to this lecturer.");
            }
        } catch (SQLException e) {
            logger.error("Failed to load courses for lecturer_id {}: {}", lecturerId, e.getMessage(), e);
            showAlert("Error", "Unable to load courses: " + e.getMessage());
        }
    }

    private void loadSubmissions() {
        submissions.clear();
        String query = """
            SELECT s.student_id, COALESCE(st.student_name, 'Unknown') AS student_name, s.mark
            FROM submissions s
            JOIN students st ON s.student_id = st.student_id
            WHERE s.course_id = ? AND s.lecturer_id = ?
        """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, selectedCourseId);
            stmt.setInt(2, lecturerId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int studentId = rs.getInt("student_id");
                String studentName = rs.getString("student_name");
                int mark = rs.getInt("mark");
                String markValue = rs.wasNull() ? "Not Graded" : String.valueOf(mark);
                submissions.add(new SubmissionReport(studentId, studentName, markValue));
            }
            logger.info("Loaded {} submissions for course_id: {}, lecturer_id: {}", submissions.size(), selectedCourseId, lecturerId);
        } catch (SQLException e) {
            logger.error("Failed to load submissions for course_id {}: {}", selectedCourseId, e.getMessage(), e);
            showAlert("Error", "Unable to load submissions: " + e.getMessage());
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.initOwner(stage);
        alert.showAndWait();
    }

    @FXML
    private void handleExit() {
        stage.close();
    }

    public static class SubmissionReport {
        private final SimpleIntegerProperty studentId;
        private final SimpleStringProperty studentName;
        private final SimpleStringProperty mark;

        public SubmissionReport(int studentId, String studentName, String mark) {
            this.studentId = new SimpleIntegerProperty(studentId);
            this.studentName = new SimpleStringProperty(studentName);
            this.mark = new SimpleStringProperty(mark);
        }

        public SimpleIntegerProperty studentIdProperty() {
            return studentId;
        }

        public SimpleStringProperty studentNameProperty() {
            return studentName;
        }

        public SimpleStringProperty markProperty() {
            return mark;
        }
    }
}
