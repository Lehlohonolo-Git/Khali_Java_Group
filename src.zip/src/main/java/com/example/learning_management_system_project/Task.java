package com.example.learning_management_system_project;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;

import java.sql.Timestamp;

public class Task {
    private final int taskId;
    private final SimpleStringProperty taskName;
    private final SimpleStringProperty taskType;
    private final SimpleStringProperty filePath;
    private final Timestamp dueDate;
    private final SimpleStringProperty instructions;
    private final SimpleDoubleProperty weight;

    public Task(int taskId, String taskName, String taskType, String filePath, Timestamp dueDate, String instructions, double weight) {
        this.taskId = taskId;
        this.taskName = new SimpleStringProperty(taskName);
        this.taskType = new SimpleStringProperty(taskType);
        this.filePath = new SimpleStringProperty(filePath != null ? filePath : "No File");
        this.dueDate = dueDate;
        this.instructions = new SimpleStringProperty(instructions != null ? instructions : "No instructions");
        this.weight = new SimpleDoubleProperty(weight);
    }

    public int getTaskId() { return taskId; }
    public String getTaskName() { return taskName.get(); }
    public String getTaskType() { return taskType.get(); }
    public String getFilePath() { return filePath.get(); }
    public Timestamp getDueDate() { return dueDate; }
    public String getInstructions() { return instructions.get(); }
    public double getWeight() { return weight.get(); }
}