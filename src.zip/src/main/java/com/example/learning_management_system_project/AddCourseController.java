package com.example.learning_management_system_project;

import com.example.learning_management_system_project.DB.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AddCourseController {

    @FXML private TextField courseNameField;
    @FXML private ComboBox<String> programDropdown;
    @FXML private TableView<Course> courseTable;
    @FXML private TableColumn<Course, String> courseNameColumn;
    @FXML private TableColumn<Course, String> programNameColumn;
    @FXML private Button updateButton;
    @FXML private Button deleteButton;
    @FXML private Pagination pagination;

    private final ObservableList<String> programList = FXCollections.observableArrayList();
    private final ObservableList<Course> courseList = FXCollections.observableArrayList();
    private static final int ITEMS_PER_PAGE = 5;
    private int totalItems;

    @FXML
    public void initialize() {
        loadPrograms();
        programDropdown.setItems(programList);
        setupTable();
        setupPagination();
        loadTotalItems();
    }

    private void setupTable() {
        courseNameColumn.setCellValueFactory(new PropertyValueFactory<>("courseName"));
        programNameColumn.setCellValueFactory(new PropertyValueFactory<>("programName"));
        courseTable.setItems(courseList);
        updateButton.setDisable(true);
        deleteButton.setDisable(true);
        courseTable.getSelectionModel().selectedItemProperty().addListener((obs, old, newValue) -> {
            updateButton.setDisable(newValue == null);
            deleteButton.setDisable(newValue == null);
            if (newValue != null) {
                courseNameField.setText(newValue.getCourseName());
                programDropdown.setValue(newValue.getProgramName());
            }
        });
    }

    private void setupPagination() {
        pagination.setPageFactory(pageIndex -> {
            loadCourses(pageIndex);
            return courseTable;
        });
    }

    private void loadTotalItems() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM courses");
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                totalItems = rs.getInt(1);
                pagination.setPageCount((int) Math.ceil((double) totalItems / ITEMS_PER_PAGE));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load total courses: " + e.getMessage());
        }
    }

    @FXML
    private void handleAddCourse() {
        String course = courseNameField.getText();
        String program = programDropdown.getValue();
        if (!course.isEmpty() && program != null) {
            try (Connection conn = DBConnection.getConnection()) {
                PreparedStatement getProgramId = conn.prepareStatement(
                        "SELECT program_id FROM programs WHERE program_name = ?"
                );
                getProgramId.setString(1, program);
                ResultSet rs = getProgramId.executeQuery();
                if (rs.next()) {
                    int programId = rs.getInt("program_id");
                    PreparedStatement insertCourse = conn.prepareStatement(
                            "INSERT INTO courses (course_name, program_id) VALUES (?, ?)"
                    );
                    insertCourse.setString(1, course);
                    insertCourse.setInt(2, programId);
                    insertCourse.executeUpdate();
                    courseNameField.clear();
                    programDropdown.getSelectionModel().clearSelection();
                    loadTotalItems();
                    loadCourses(pagination.getCurrentPageIndex());
                    showAlert("Success", "Course added!");
                } else {
                    showAlert("Error", "Program not found.");
                }
            } catch (SQLException e) {
                showAlert("Error", "Failed to add course: " + e.getMessage());
            }
        } else {
            showAlert("Error", "Please fill all fields.");
        }
    }

    @FXML
    private void handleUpdateCourse() {
        Course selected = courseTable.getSelectionModel().getSelectedItem();
        String newCourseName = courseNameField.getText();
        String newProgram = programDropdown.getValue();
        if (selected != null && !newCourseName.isEmpty() && newProgram != null) {
            try (Connection conn = DBConnection.getConnection()) {
                PreparedStatement getProgramId = conn.prepareStatement(
                        "SELECT program_id FROM programs WHERE program_name = ?"
                );
                getProgramId.setString(1, newProgram);
                ResultSet rs = getProgramId.executeQuery();
                if (rs.next()) {
                    int programId = rs.getInt("program_id");
                    PreparedStatement updateStmt = conn.prepareStatement(
                            "UPDATE courses SET course_name = ?, program_id = ? WHERE course_name = ? AND program_id = (SELECT program_id FROM programs WHERE program_name = ?)"
                    );
                    updateStmt.setString(1, newCourseName);
                    updateStmt.setInt(2, programId);
                    updateStmt.setString(3, selected.getCourseName());
                    updateStmt.setString(4, selected.getProgramName());
                    int rows = updateStmt.executeUpdate();
                    if (rows > 0) {
                        loadCourses(pagination.getCurrentPageIndex());
                        courseNameField.clear();
                        programDropdown.getSelectionModel().clearSelection();
                        courseTable.getSelectionModel().clearSelection();
                        showAlert("Success", "Course updated!");
                    } else {
                        showAlert("Error", "Course not found.");
                    }
                } else {
                    showAlert("Error", "Program not found.");
                }
            } catch (SQLException e) {
                showAlert("Error", "Failed to update course: " + e.getMessage());
            }
        } else {
            showAlert("Error", "Please select a course and fill all fields.");
        }
    }

    @FXML
    private void handleDeleteCourse() {
        Course selected = courseTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            try (Connection conn = DBConnection.getConnection()) {
                PreparedStatement deleteStmt = conn.prepareStatement(
                        "DELETE FROM courses WHERE course_name = ? AND program_id = (SELECT program_id FROM programs WHERE program_name = ?)"
                );
                deleteStmt.setString(1, selected.getCourseName());
                deleteStmt.setString(2, selected.getProgramName());
                int rows = deleteStmt.executeUpdate();
                if (rows > 0) {
                    loadTotalItems();
                    loadCourses(pagination.getCurrentPageIndex());
                    courseNameField.clear();
                    programDropdown.getSelectionModel().clearSelection();
                    courseTable.getSelectionModel().clearSelection();
                    showAlert("Success", "Course deleted!");
                } else {
                    showAlert("Error", "Course not found.");
                }
            } catch (SQLException e) {
                showAlert("Error", "Failed to delete course: " + e.getMessage());
            }
        } else {
            showAlert("Error", "Please select a course to delete.");
        }
    }

    private void loadPrograms() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT program_name FROM programs");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                programList.add(rs.getString("program_name"));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load programs: " + e.getMessage());
        }
    }

    private void loadCourses(int pageIndex) {
        courseList.clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT c.course_name, p.program_name " +
                             "FROM courses c JOIN programs p ON c.program_id = p.program_id " +
                             "ORDER BY c.course_name LIMIT ? OFFSET ?"
             )) {
            stmt.setInt(1, ITEMS_PER_PAGE);
            stmt.setInt(2, pageIndex * ITEMS_PER_PAGE);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                courseList.add(new Course(
                        rs.getString("course_name"),
                        rs.getString("program_name")
                ));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load courses: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    public static class Course {
        private final String courseName;
        private final String programName;

        public Course(String courseName, String programName) {
            this.courseName = courseName;
            this.programName = programName;
        }

        public String getCourseName() {
            return courseName;
        }

        public String getProgramName() {
            return programName;
        }
    }

    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    private Stage getStageFromEvent(ActionEvent event) {
        Object source = event.getSource();
        if (source instanceof Node) {
            return (Stage) ((Node) source).getScene().getWindow();
        } else if (source instanceof MenuItem) {
            return (Stage) MenuItem.class.cast(source).getParentPopup().getOwnerWindow();
        }
        throw new IllegalStateException("Cannot determine Stage from event source.");
    }

    private void loadFXML(String fxmlPath, String title, ActionEvent event) throws IOException {
        URL resource = getClass().getResource(fxmlPath);
        if (resource == null) {
            throw new IllegalStateException("Cannot find FXML file at: " + fxmlPath);
        }
        Stage currentStage = (stage != null) ? stage : getStageFromEvent(event);
        FXMLLoader loader = new FXMLLoader(resource);
        Scene scene = new Scene(loader.load(), 900, 500);
        currentStage.setScene(scene);
        currentStage.setTitle(title);

        Object controller = loader.getController();
        if (controller != null) {
            try {
                Method setStageMethod = controller.getClass().getMethod("setStage", Stage.class);
                setStageMethod.invoke(controller, currentStage);
            } catch (NoSuchMethodException e) {
                // Optional stage setting method is absent — safe to ignore.
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        currentStage.show();
    }

    @FXML
    private void handleViewStudents(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/StudentDashboard.fxml", "Student Dashboard", event);
    }

    @FXML
    private void handleProgressReport(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleExportReport(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/Reports.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleAbout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AboutUs.fxml", "About Us", event);
    }

    @FXML
    private void handleDocumentation(ActionEvent event) {
        System.out.println("Documentation clicked.");
    }

    @FXML
    private void handleViewCourses(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewCourses.fxml", "View Courses", event);
    }

    @FXML
    private void handleExit(ActionEvent event) {
        getStageFromEvent(event).close();
    }

    @FXML
    private void handleHome(ActionEvent event) throws IOException {
        URL resource = getClass().getResource("/com/example/learning_management_system_project/fxmls/Home.fxml");
        if (resource == null) {
            throw new IllegalStateException("Cannot find FXML file at: /com/example/learning_management_system_project/fxmls/Home.fxml");
        }
        FXMLLoader loader = new FXMLLoader(resource);
        Scene scene = ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow().getScene();
        scene.setRoot(loader.load());
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        System.out.println("Refresh clicked.");
    }

    @FXML
    private void handleAddCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddCourse.fxml", "Add Course", event);
    }

    @FXML
    private void handleAddStudent(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/StudentDashboard.fxml", "Student Dashboard", event);
    }

    @FXML
    private void handleViewStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleAssignCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AdminAssignCoursesView.fxml", "Assign Courses", event);
    }

    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/Login.fxml", "Login", event);
    }

    @FXML
    private void handleAddLecturer(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddLecturer.fxml", "Add Lecturer", event);
    }

    @FXML
    private void handleViewLecturers(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewLecturers.fxml", "View Lecturers", event);
    }

    @FXML
    private void handleAddFaculty(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddFaculty.fxml", "Add Faculty", event);
    }

    @FXML
    private void handleViewFaculties(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewFaculties.fxml", "View Faculties", event);
    }
}