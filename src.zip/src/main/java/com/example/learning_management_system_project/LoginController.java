package com.example.learning_management_system_project;

import com.example.learning_management_system_project.DB.DBConnection;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginController {

    private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private ComboBox<String> roleComboBox;
    @FXML private Button loginButton;
    @FXML private Hyperlink forgotPasswordLink;

    @FXML
    public void initialize() {
        roleComboBox.getItems().addAll("Student", "Lecturer", "Admin");
        roleComboBox.setValue("Student"); // Default role
    }

    @FXML
    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();
        String role = roleComboBox.getValue();

        if (username.isEmpty() || password.isEmpty() || role == null) {
            showAlert("Error", "Please fill in all fields.");
            logger.warn("Login attempt with empty fields: username={}, role={}", username, role);
            return;
        }

        // Admin login logic
        if (role.equals("Admin")) {
            if (username.equals("Pheko") && password.equals("12345")) {
                logger.info("Admin login successful: {}", username);
                navigateToAdminHome();
                return;
            } else {
                showAlert("Error", "Invalid admin credentials.");
                logger.warn("Failed admin login attempt: {}", username);
                return;
            }
        }

        // Student and Lecturer login logic
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT student_id, lecturer_id FROM users WHERE username = ? AND password = ? AND role = ?")) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, role);
            ResultSet rs = stmt.executeQuery();

            if (!rs.next()) {
                showAlert("Error", "Invalid username, password, or role.");
                logger.warn("Failed login attempt: username={}, role={}", username, role);
                return;
            }

            if (role.equals("Student")) {
                int studentId = rs.getInt("student_id");
                if (!rs.wasNull()) {
                    logger.info("Successful student login: username={}, student_id={}", username, studentId);
                    navigateToStudentDashboard(studentId);
                } else {
                    showAlert("Error", "No student associated with this account.");
                    logger.error("Student role selected but no student_id: username={}", username);
                }
            } else if (role.equals("Lecturer")) {
                int lecturerId = rs.getInt("lecturer_id");
                if (!rs.wasNull()) {
                    logger.info("Successful lecturer login: username={}, lecturer_id={}", username, lecturerId);
                    navigateToLecturerDashboard(lecturerId);
                } else {
                    showAlert("Error", "No lecturer associated with this account.");
                    logger.error("Lecturer role selected but no lecturer_id: username={}", username);
                }
            }
        } catch (SQLException e) {
            showAlert("Error", "Login failed: " + e.getMessage());
            logger.error("SQLException during login: username={}, role={}, error={}", username, role, e.getMessage(), e);
        }
    }

    @FXML
    private void handleForgotPassword() {
        showAlert("Information", "Password reset functionality is not implemented. Please contact the administrator.");
        logger.info("Forgot password link clicked");
    }

    private void navigateToAdminHome() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/learning_management_system_project/fxmls/Home.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Admin Home");
            stage.show();
            logger.info("Navigated to admin home (Home.fxml)");
        } catch (IOException e) {
            showAlert("Error", "Failed to load admin home: " + e.getMessage());
            logger.error("IOException loading Home.fxml: {}", e.getMessage(), e);
        }
    }

    private void navigateToStudentDashboard(int studentId) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/learning_management_system_project/fxmls/StudentDashboard.fxml"));
            Parent root = loader.load();
            StudentDashboardController controller = loader.getController();
            controller.setStudentId(studentId);
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Student Dashboard");
            stage.show();
        } catch (IOException e) {
            showAlert("Error", "Failed to load student dashboard: " + e.getMessage());
        }
    }

    private void navigateToLecturerDashboard(int lecturerId) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/learning_management_system_project/fxmls/LecturerDashboard.fxml"));
            Parent root = loader.load();
            LecturerDashboardController controller = loader.getController();
            controller.setLecturerId(lecturerId);
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Lecturer Dashboard");
            stage.show();
        } catch (IOException e) {
            showAlert("Error", "Failed to load lecturer dashboard: " + e.getMessage());
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
