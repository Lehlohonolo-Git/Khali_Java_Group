package com.example.learning_management_system_project;

import com.example.learning_management_system_project.DB.DBConnection;
import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class StudentDashboardController {
    private static final Logger logger = LoggerFactory.getLogger(StudentDashboardController.class);

    @FXML private ComboBox<String> courseComboBox;
    @FXML private Label courseLabel;
    @FXML private Button logoutButton;
    @FXML private TabPane mainTabPane;
    @FXML private ListView<Object> streamList;
    @FXML private ListView<TaskSubmission> taskList;
    @FXML private ListView<Material> materialList;
    @FXML private VBox progressBox;
    @FXML private ProgressBar progressBar;
    @FXML private Label progressLabel;
    @FXML private TextArea filePreviewText;
    @FXML private ImageView filePreviewImage;

    private final ObservableList<String> courses = FXCollections.observableArrayList();
    private final ObservableList<Object> streamItems = FXCollections.observableArrayList();
    private final ObservableList<TaskSubmission> tasks = FXCollections.observableArrayList();
    private final ObservableList<Material> materials = FXCollections.observableArrayList();
    private int selectedCourseId = -1;
    private int studentId;
    private Stage stage;

    public void setStudentId(int studentId) {
        this.studentId = studentId;
        logger.info("Set studentId to {} for dashboard", studentId);
        loadCourses();
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    public void initialize() {
        courseComboBox.setItems(courses);
        streamList.setItems(streamItems);
        taskList.setItems(tasks);
        materialList.setItems(materials);

        streamList.setCellFactory(param -> new StreamListCell());
        taskList.setCellFactory(param -> new TaskListCell());
        materialList.setCellFactory(param -> new MaterialListCell());

        courseComboBox.setOnAction(e -> {
            String selectedCourse = courseComboBox.getValue();
            if (selectedCourse != null) {
                try {
                    logger.debug("Selected course string: {}", selectedCourse);
                    selectedCourseId = Integer.parseInt(selectedCourse.split(":")[0]);
                    courseLabel.setText(selectedCourse.split(":")[1].trim());
                    logger.info("Selected course_id: {}", selectedCourseId);
                    loadStream();
                    loadTasks();
                    loadMaterials();
                    loadProgress();
                    clearPreview();
                } catch (NumberFormatException ex) {
                    logger.error("Invalid course format: {}", selectedCourse, ex);
                    showAlert("Error", "Invalid course selected.");
                }
            } else {
                selectedCourseId = -1;
                courseLabel.setText("No Course Selected");
                streamItems.clear();
                tasks.clear();
                materials.clear();
                progressBar.setProgress(-1);
                progressLabel.setText("0.00%");
                progressBox.getChildren().clear();
                clearPreview();
                logger.info("No course selected, cleared all lists.");
            }
        });

        taskList.getSelectionModel().selectedItemProperty().addListener((obs, old, newSelection) -> {
            if (newSelection != null) {
                displayFileContent(newSelection);
            } else {
                clearPreview();
            }
        });

        materialList.getSelectionModel().selectedItemProperty().addListener((obs, old, newSelection) -> {
            if (newSelection != null) {
                displayMaterialContent(newSelection);
            } else {
                clearPreview();
            }
        });

        applyAnimations();
    }

    private void applyAnimations() {
        FadeTransition fade = new FadeTransition(Duration.millis(1000), mainTabPane);
        fade.setFromValue(1.0);
        fade.setToValue(0.95);
        fade.setCycleCount(FadeTransition.INDEFINITE);
        fade.setAutoReverse(true);
        fade.play();

        if (logoutButton != null) {
            ScaleTransition scale = new ScaleTransition(Duration.millis(200), logoutButton);
            scale.setToX(1.1);
            scale.setToY(1.1);
            logoutButton.setOnMouseEntered(e -> {
                logoutButton.setStyle(logoutButton.getStyle() + "-fx-background-color: #c0392b;");
                scale.playFromStart();
            });
            logoutButton.setOnMouseExited(e -> {
                logoutButton.setStyle(
                        logoutButton.getStyle().replace("-fx-background-color: #c0392b;", "-fx-background-color: #e74c3c;")
                );
                ScaleTransition reverse = new ScaleTransition(Duration.millis(200), logoutButton);
                reverse.setToX(1.0);
                reverse.setToY(1.0);
                reverse.play();
            });
        }
    }

    private void loadCourses() {
        if (studentId == 0) {
            logger.error("Student ID not set. Cannot load courses.");
            showAlert("Error", "User not authenticated. Please log in.");
            return;
        }
        courses.clear();
        String query = "SELECT DISTINCT c.course_id, c.course_name " +
                "FROM student_courses sc " +
                "JOIN courses c ON sc.course_id = c.course_id " +
                "WHERE sc.student_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();
            int count = 0;
            while (rs.next()) {
                count++;
                courses.add(rs.getInt("course_id") + ": " + rs.getString("course_name"));
                logger.debug("Loaded course: {} (course_id: {})", rs.getString("course_name"), rs.getInt("course_id"));
            }
            logger.info("Loaded {} courses for student_id: {}", count, studentId);
            if (count == 0) {
                logger.warn("No courses found for student_id: {}. Verify student_courses table.", studentId);
                showAlert("No Courses", "You are not enrolled in any courses.");
            }
        } catch (SQLException ex) {
            logger.error("Failed to load courses for student_id {}: {} (SQL State: {}, Error Code: {})",
                    studentId, ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), ex);
            showAlert("Error", "Unable to load courses: " + ex.getMessage());
        }
    }

    private void loadStream() {
        streamItems.clear();
        if (selectedCourseId == -1) {
            logger.warn("No course selected, skipping stream load.");
            return;
        }
        // Load announcements
        String announcementQuery = "SELECT announcement_id, content, posted_date " +
                "FROM announcements " +
                "WHERE course_id = ? " +
                "ORDER BY posted_date DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(announcementQuery)) {
            pstmt.setInt(1, selectedCourseId);
            ResultSet rs = pstmt.executeQuery();
            int count = 0;
            while (rs.next()) {
                streamItems.add(new Announcement(
                        rs.getInt("announcement_id"),
                        rs.getString("content"),
                        rs.getTimestamp("posted_date")
                ));
                count++;
            }
            logger.info("Loaded {} announcements for course_id: {}", count, selectedCourseId);
        } catch (SQLException ex) {
            logger.error("Failed to load announcements for course_id {}: {} (SQL State: {}, Error Code: {})",
                    selectedCourseId, ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), ex);
        }

        // Load tasks
        String taskQuery = "SELECT task_id, task_name, task_type, file_path, due_date, instructions, weight " +
                "FROM tasks " +
                "WHERE course_id = ? " +
                "ORDER BY due_date DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(taskQuery)) {
            pstmt.setInt(1, selectedCourseId);
            ResultSet rs = pstmt.executeQuery();
            int count = 0;
            while (rs.next()) {
                streamItems.add(new Task(
                        rs.getInt("task_id"),
                        rs.getString("task_name"),
                        rs.getString("task_type"),
                        rs.getString("file_path"),
                        rs.getTimestamp("due_date"),
                        rs.getString("instructions"),
                        rs.getDouble("weight")
                ));
                count++;
            }
            logger.info("Loaded {} tasks for stream, course_id: {}", count, selectedCourseId);
            if (count == 0) {
                logger.warn("No tasks found for course_id: {}. Verify tasks table.", selectedCourseId);
            }
        } catch (SQLException ex) {
            logger.error("Failed to load tasks for stream, course_id {}: {} (SQL State: {}, Error Code: {})",
                    selectedCourseId, ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), ex);
        }

        // Load materials
        String materialQuery = "SELECT material_id, material_name, file_path, upload_date " +
                "FROM materials " +
                "WHERE course_id = ? " +
                "ORDER BY upload_date DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(materialQuery)) {
            pstmt.setInt(1, selectedCourseId);
            ResultSet rs = pstmt.executeQuery();
            int count = 0;
            while (rs.next()) {
                streamItems.add(new Material(
                        rs.getInt("material_id"),
                        rs.getString("material_name"),
                        rs.getString("file_path"),
                        rs.getTimestamp("upload_date")
                ));
                count++;
            }
            logger.info("Loaded {} materials for stream, course_id: {}", count, selectedCourseId);
            if (count == 0) {
                logger.warn("No materials found for course_id: {}. Verify materials table.", selectedCourseId);
            }
        } catch (SQLException ex) {
            logger.error("Failed to load materials for stream, course_id {}: {} (SQL State: {}, Error Code: {})",
                    selectedCourseId, ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), ex);
        }
    }

    private void loadTasks() {
        tasks.clear();
        if (selectedCourseId == -1) {
            logger.warn("No course selected, skipping tasks load.");
            return;
        }
        String query = "SELECT t.task_id, t.task_name, t.task_type, t.file_path, t.due_date, t.instructions, t.weight, " +
                "s.file_path AS submission_file_path, s.mark, s.submission_status, s.submission_date, s.comments " +
                "FROM tasks t " +
                "LEFT JOIN submissions s ON t.task_id = s.task_id AND s.student_id = ? AND s.course_id = ? " +
                "WHERE t.course_id = ? " +
                "ORDER BY t.due_date DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, studentId);
            pstmt.setInt(2, selectedCourseId);
            pstmt.setInt(3, selectedCourseId);
            logger.debug("Executing loadTasks with course_id: {}, student_id: {}", selectedCourseId, studentId);
            ResultSet rs = pstmt.executeQuery();
            int count = 0;
            while (rs.next()) {
                int taskId = rs.getInt("task_id");
                String taskName = rs.getString("task_name");
                String taskType = rs.getString("task_type");
                String taskFilePath = rs.getString("file_path");
                Timestamp dueDate = rs.getTimestamp("due_date");
                String instructions = rs.getString("instructions");
                double weight = rs.getDouble("weight");
                String submissionFilePath = rs.getString("submission_file_path");
                Double mark = rs.getObject("mark") != null ? rs.getDouble("mark") : null;
                String submissionStatus = rs.getString("submission_status");
                Timestamp submissionDate = rs.getTimestamp("submission_date");
                String comments = rs.getString("comments");

                String status = determineStatus(submissionStatus, mark, dueDate, submissionDate);
                String markText = mark != null ? String.format("%.2f", mark) : "-";
                String filePathText = submissionFilePath != null ? submissionFilePath : "No File";
                String fileContent = submissionFilePath != null && submissionFilePath.toLowerCase().endsWith(".txt") ?
                        getFileContent(submissionFilePath) : null;

                tasks.add(new TaskSubmission(taskId, taskName, taskType, instructions, status, markText, filePathText, weight, fileContent, comments));
                logger.debug("Added task: task_id={}, task_name='{}', status='{}', file_path='{}'",
                        taskId, taskName, status, submissionFilePath);
                count++;
            }
            logger.info("Query returned {} tasks for course_id: {}, student_id: {}", count, selectedCourseId, studentId);
            logger.debug("Tasks list size after loading: {}", tasks.size());
            if (count == 0) {
                logger.warn("No tasks found for course_id: {}, student_id: {}. Check tasks and course_id.", selectedCourseId, studentId);
                showAlert("Info", "No tasks found for the selected course.");
            }
        } catch (SQLException ex) {
            logger.error("Failed to load tasks for course_id {}: {} (SQL State: {}, Error Code: {})",
                    selectedCourseId, ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), ex);
            showAlert("Error", "Unable to load tasks: " + ex.getMessage());
        }
    }

    private String determineStatus(String submissionStatus, Double mark, Timestamp dueDate, Timestamp submissionDate) {
        if (submissionStatus == null) return "Not Submitted";
        if (mark != null) return String.format("Graded (%.2f)", mark);
        if (submissionStatus.equals("Submitted") && dueDate != null && submissionDate != null) {
            return submissionDate.after(dueDate) ? "Submitted (Late)" : "Submitted";
        }
        return submissionStatus;
    }

    private String getFileContent(String filePath) {
        try {
            return Files.readString(new File(filePath).toPath());
        } catch (IOException e) {
            logger.warn("Failed to read file content for path: {}", filePath, e);
            return "Error reading file content.";
        }
    }

    private void loadMaterials() {
        materials.clear();
        if (selectedCourseId == -1) {
            logger.warn("No course selected, skipping materials load.");
            return;
        }
        String query = "SELECT material_id, material_name, file_path, upload_date " +
                "FROM materials " +
                "WHERE course_id = ? " +
                "ORDER BY upload_date DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, selectedCourseId);
            logger.debug("Executing loadMaterials with course_id: {}", selectedCourseId);
            ResultSet rs = pstmt.executeQuery();
            int count = 0;
            while (rs.next()) {
                materials.add(new Material(
                        rs.getInt("material_id"),
                        rs.getString("material_name"),
                        rs.getString("file_path"),
                        rs.getTimestamp("upload_date")
                ));
                logger.debug("Added material: material_id={}, material_name='{}', file_path='{}'",
                        rs.getInt("material_id"), rs.getString("material_name"), rs.getString("file_path"));
                count++;
            }
            logger.info("Query returned {} materials for course_id: {}", count, selectedCourseId);
            logger.debug("Materials list size after loading: {}", materials.size());
            if (count == 0) {
                logger.warn("No materials found for course_id: {}. Check materials and course_id.", selectedCourseId);
                showAlert("Info", "No materials found for the selected course.");
            }
        } catch (SQLException ex) {
            logger.error("Failed to load materials for course_id {}: {} (SQL State: {}, Error Code: {})",
                    selectedCourseId, ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), ex);
            showAlert("Error", "Unable to load materials: " + ex.getMessage());
        }
    }

    private void loadProgress() {
        progressBox.getChildren().clear();
        if (selectedCourseId == -1) {
            progressBar.setProgress(-1);
            progressLabel.setText("0.00%");
            logger.warn("No course selected, skipping progress load.");
            return;
        }

        double totalWeightedScore = 0.0;
        ObservableList<TaskProgress> taskProgressList = FXCollections.observableArrayList();

        // Fetch tasks and submission marks
        String query = "SELECT t.task_id, t.task_name, t.task_type, t.weight, s.mark, s.comments " +
                "FROM tasks t " +
                "LEFT JOIN submissions s ON t.task_id = s.task_id AND s.student_id = ? AND s.course_id = ? " +
                "WHERE t.course_id = ? " +
                "ORDER BY t.task_name";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, studentId);
            pstmt.setInt(2, selectedCourseId);
            pstmt.setInt(3, selectedCourseId);
            ResultSet rs = pstmt.executeQuery();
            int count = 0;
            while (rs.next()) {
                int taskId = rs.getInt("task_id");
                String taskName = rs.getString("task_name");
                String taskType = rs.getString("task_type");
                double weight = rs.getDouble("weight");
                Double mark = rs.getObject("mark") != null ? rs.getDouble("mark") : null;
                String comments = rs.getString("comments");

                if (weight < 0 || weight > 1) {
                    logger.warn("Invalid weight {} for task_id: {}. Skipping.", weight, taskId);
                    continue;
                }

                double weightedScore = mark != null ? mark * weight : 0.0;
                if (mark != null) {
                    totalWeightedScore += weightedScore;
                }

                taskProgressList.add(new TaskProgress(taskId, taskName, taskType, weight, mark, weightedScore, comments));
                logger.debug("Task: {}, mark: {}, weight: {}, weighted_score: {}", taskName, mark, weight, weightedScore);
                count++;
            }
            logger.info("Loaded {} tasks for progress, course_id: {}, student_id: {}", count, selectedCourseId, studentId);

            // Calculate progress as the sum of weighted scores, treated directly as percentage
            double progressPercent = totalWeightedScore; // e.g., 13.0 (not multiplied by 100)
            progressBar.setProgress(Math.min(progressPercent / 100.0, 1.0));
            progressLabel.setText(String.format("%.2f%%", progressPercent));
            logger.info("Calculated progress: {}% (total_weighted_score: {})",
                    progressPercent, totalWeightedScore);

            // Update student_progress table
            String updateProgressQuery = "INSERT INTO student_progress (student_id, course_id, progress_percent) " +
                    "VALUES (?, ?, ?) " +
                    "ON CONFLICT (student_id, course_id) DO UPDATE SET progress_percent = EXCLUDED.progress_percent";
            try (PreparedStatement updateStmt = conn.prepareStatement(updateProgressQuery)) {
                updateStmt.setInt(1, studentId);
                updateStmt.setInt(2, selectedCourseId);
                updateStmt.setDouble(3, Math.min(progressPercent, 100.0));
                updateStmt.executeUpdate();
                logger.info("Updated student_progress for student_id: {}, course_id: {}, progress_percent: {}",
                        studentId, selectedCourseId, Math.min(progressPercent, 100.0));
            }

            // Display tasks in progressBox
            VBox marksBox = new VBox(5);
            marksBox.setStyle("-fx-background-color: #ffffff; -fx-padding: 10; -fx-background-radius: 5; -fx-border-color: #e0e0e0; -fx-border-radius: 5;");
            for (TaskProgress tp : taskProgressList) {
                HBox markItem = new HBox(10);
                Label taskLabel = new Label(tp.taskName + " (" + tp.taskType + ")");
                taskLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14; -fx-text-fill: #333333;");
                Label weightLabel = new Label(String.format("Weight: %.2f%%", tp.weight * 100));
                weightLabel.setStyle("-fx-font-size: 12; -fx-text-fill: #666666;");
                Label markLabel = new Label("Mark: " + (tp.mark != null ? String.format("%.2f", tp.mark) : "-"));
                markLabel.setStyle("-fx-font-size: 12; -fx-text-fill: #666666;");
                // Display weighted score as (mark * weight)%, not multiplied by 100
                double displayWeightedPercent = tp.mark != null ? (tp.mark * tp.weight) : 0.0;
                Label weightedLabel = new Label(String.format("Weighted: %.2f%%", displayWeightedPercent));
                weightedLabel.setStyle("-fx-font-size: 12; -fx-text-fill: #666666;");
                Label commentsLabel = new Label("Comments: " + (tp.comments != null ? tp.comments : "None"));
                commentsLabel.setStyle("-fx-font-size: 12; -fx-text-fill: #666666;");
                markItem.getChildren().addAll(taskLabel, weightLabel, markLabel, weightedLabel, commentsLabel);
                marksBox.getChildren().add(markItem);
            }

            Label summaryLabel = new Label(String.format("Total Weighted Score: %.2f%%", totalWeightedScore));
            summaryLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14; -fx-text-fill: #333333;");
            Label progressSummaryLabel = new Label(String.format("Overall Progress: %.2f%%", progressPercent));
            progressSummaryLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14; -fx-text-fill: #333333;");

            progressBox.getChildren().addAll(
                    new Label("Task Progress:") {{
                        setStyle("-fx-font-weight: bold; -fx-font-size: 14; -fx-text-fill: #333333;");
                    }},
                    marksBox,
                    summaryLabel,
                    progressSummaryLabel
            );

        } catch (SQLException ex) {
            logger.error("Failed to load progress for course_id {}: {} (SQL State: {}, Error Code: {})",
                    selectedCourseId, ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), ex);
            showAlert("Error", "Unable to load progress: " + ex.getMessage());
            progressBar.setProgress(-1);
            progressLabel.setText("0.00%");
        }
    }

    private void handleUpload(int taskId, String taskName) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Upload Submission for " + taskName);
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Text Files", "*.txt"),
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"),
                new FileChooser.ExtensionFilter("PDF Files", "*.pdf")
        );
        File file = fileChooser.showOpenDialog(stage);
        if (file != null) {
            if (file.length() > 10 * 1024 * 1024) { // 10MB limit
                showAlert("Error", "File size exceeds 10MB limit.");
                logger.warn("File too large for task_id: {}, size: {}", taskId, file.length());
                return;
            }
            try (Connection conn = DBConnection.getConnection()) {
                int lecturerId;
                try (PreparedStatement pstmt = conn.prepareStatement(
                        "SELECT lecturer_id FROM tasks WHERE task_id = ? AND course_id = ?")) {
                    pstmt.setInt(1, taskId);
                    pstmt.setInt(2, selectedCourseId);
                    ResultSet rs = pstmt.executeQuery();
                    if (rs.next()) {
                        lecturerId = rs.getInt("lecturer_id");
                    } else {
                        showAlert("Error", "Task not found.");
                        logger.error("Task not found: task_id {}, course_id {}", taskId, selectedCourseId);
                        return;
                    }
                }

                String fileContent = file.getName().toLowerCase().endsWith(".txt") ? Files.readString(file.toPath()) : null;
                Timestamp dueDate;
                try (PreparedStatement pstmt = conn.prepareStatement("SELECT due_date FROM tasks WHERE task_id = ?")) {
                    pstmt.setInt(1, taskId);
                    ResultSet rs = pstmt.executeQuery();
                    dueDate = rs.next() ? rs.getTimestamp("due_date") : null;
                }

                String status = dueDate != null && dueDate.before(Timestamp.valueOf(LocalDateTime.now())) ? "Late" : "Pending";
                String query = "INSERT INTO submissions (student_id, lecturer_id, course_id, task_id, file_path, file_content, submission_status, submission_date) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?) " +
                        "ON CONFLICT (student_id, course_id, task_id) " +
                        "DO UPDATE SET file_path = EXCLUDED.file_path, file_content = EXCLUDED.file_content, " +
                        "submission_status = EXCLUDED.submission_status, submission_date = EXCLUDED.submission_date, mark = NULL, comments = NULL";
                try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                    pstmt.setInt(1, studentId);
                    pstmt.setInt(2, lecturerId);
                    pstmt.setInt(3, selectedCourseId);
                    pstmt.setInt(4, taskId);
                    pstmt.setString(5, file.getAbsolutePath());
                    pstmt.setString(6, fileContent);
                    pstmt.setString(7, status);
                    pstmt.setTimestamp(8, Timestamp.valueOf(LocalDateTime.now()));
                    pstmt.executeUpdate();
                }
                showAlert("Success", "File uploaded as " + status + ". Click Submit to send to lecturer.");
                logger.info("Uploaded submission for task_id: {}, status: {}", taskId, status);
                loadTasks();
                taskList.getSelectionModel().select(tasks.stream().filter(t -> t.getTaskId() == taskId).findFirst().orElse(null));
            } catch (SQLException ex) {
                logger.error("Failed to upload submission for task_id {}: {} (SQL State: {}, Error Code: {})",
                        taskId, ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), ex);
                showAlert("Error", "Upload failed: " + ex.getMessage());
            } catch (IOException ex) {
                logger.error("Failed to upload submission for task_id {}: {}", taskId, ex.getMessage(), ex);
                showAlert("Error", "Upload failed: " + ex.getMessage());
            }
        }
    }

    private void handleSubmit(int taskId, String taskName) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "Submit " + taskName + " to lecturer?", ButtonType.YES, ButtonType.NO);
        if (confirm.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) {
            logger.info("Submission cancelled for task_id: {}", taskId);
            return;
        }
        try (Connection conn = DBConnection.getConnection()) {
            String checkQuery = "SELECT file_path, submission_status " +
                    "FROM submissions " +
                    "WHERE student_id = ? AND course_id = ? AND task_id = ?";
            String submissionStatus = null;
            try (PreparedStatement pstmt = conn.prepareStatement(checkQuery)) {
                pstmt.setInt(1, studentId);
                pstmt.setInt(2, selectedCourseId);
                pstmt.setInt(3, taskId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    if (rs.getString("file_path") == null) {
                        showAlert("Error", "Please upload a file first.");
                        logger.warn("No file uploaded for task_id: {}", taskId);
                        return;
                    }
                    submissionStatus = rs.getString("submission_status");
                } else {
                    showAlert("Error", "No file uploaded for this task.");
                    logger.warn("No submission found for task_id: {}, student_id: {}, course_id: {}", taskId, studentId, selectedCourseId);
                    return;
                }
            }

            if ("Submitted".equals(submissionStatus)) {
                showAlert("Error", "Task already submitted.");
                logger.warn("Task already submitted: task_id {}", taskId);
                return;
            }

            String updateQuery = "UPDATE submissions " +
                    "SET submission_status = 'Submitted' " +
                    "WHERE student_id = ? AND course_id = ? AND task_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(updateQuery)) {
                pstmt.setInt(1, studentId);
                pstmt.setInt(2, selectedCourseId);
                pstmt.setInt(3, taskId);
                pstmt.executeUpdate();
                showAlert("Success", taskName + " submitted to lecturer.");
                logger.info("Submitted task_id: {}", taskId);
                loadTasks();
            }
        } catch (SQLException ex) {
            logger.error("Failed to submit task_id {}: {} (SQL State: {}, Error Code: {})",
                    taskId, ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), ex);
            showAlert("Error", "Submission failed: " + ex.getMessage());
        }
    }

    private void handleMaterialDownload(Material material) {
        if (material.getFilePath() == null || material.getFilePath().equals("No File")) {
            showAlert("Error", "No file available for download.");
            logger.warn("No file for material_id: {}", material.getMaterialId());
            return;
        }
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Material: " + material.getMaterialName());
        fileChooser.setInitialFileName(new File(material.getFilePath()).getName());
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Files", "*.*"),
                new FileChooser.ExtensionFilter("Text Files", "*.txt"),
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"),
                new FileChooser.ExtensionFilter("PDF Files", "*.pdf")
        );
        File destination = fileChooser.showSaveDialog(stage);
        if (destination != null) {
            try {
                Files.copy(new File(material.getFilePath()).toPath(), destination.toPath());
                showAlert("Success", "Material downloaded to: " + destination.getAbsolutePath());
                logger.info("Downloaded material {} to {}", material.getMaterialName(), destination.getAbsolutePath());
            } catch (IOException ex) {
                logger.error("Failed to download material {}: {}", material.getMaterialName(), ex.getMessage(), ex);
                showAlert("Error", "Download failed: " + ex.getMessage());
            }
        }
    }

    private void handleTaskDownload(TaskSubmission task) {
        if (task.getFilePath() == null || task.getFilePath().equals("No File")) {
            showAlert("Error", "No file available for download.");
            logger.warn("No file for task_id: {}", task.getTaskId());
            return;
        }
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Task Submission: " + task.getTaskName());
        fileChooser.setInitialFileName(new File(task.getFilePath()).getName());
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Files", "*.*"),
                new FileChooser.ExtensionFilter("Text Files", "*.txt"),
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"),
                new FileChooser.ExtensionFilter("PDF Files", "*.pdf")
        );
        File destination = fileChooser.showSaveDialog(stage);
        if (destination != null) {
            try {
                Files.copy(new File(task.getFilePath()).toPath(), destination.toPath());
                showAlert("Success", "Task submission downloaded to: " + destination.getAbsolutePath());
                logger.info("Downloaded task submission {} to {}", task.getTaskName(), destination.getAbsolutePath());
            } catch (IOException ex) {
                logger.error("Failed to download task submission {}: {}", task.getTaskName(), ex.getMessage(), ex);
                showAlert("Error", "Download failed: " + ex.getMessage());
            }
        }
    }

    private void displayFileContent(TaskSubmission task) {
        clearPreview();
        String filePath = task.getFilePath();
        String comments = task.getComments() != null ? task.getComments() : "None";
        if (filePath == null || filePath.equals("No File")) {
            filePreviewText.setText("No file selected.\nInstructions: " + task.getInstructions() + "\nComments: " + comments);
            filePreviewText.setVisible(true);
            return;
        }
        if (filePath.toLowerCase().endsWith(".txt")) {
            String content = task.getFileContent() != null ? task.getFileContent() : "Error reading file.";
            filePreviewText.setText(content + "\n\nInstructions: " + task.getInstructions() + "\nComments: " + comments);
            filePreviewText.setVisible(true);
        } else if (filePath.toLowerCase().endsWith(".png") || filePath.toLowerCase().endsWith(".jpg") || filePath.toLowerCase().endsWith(".jpeg")) {
            try {
                Image image = new Image(new File(filePath).toURI().toString());
                filePreviewImage.setImage(image);
                filePreviewImage.setVisible(true);
                filePreviewText.setText("Instructions: {} + \nComments: {}");
                filePreviewText.setVisible(true);
            } catch (Exception ex) {
                filePreviewText.setText("Error loading image.\nInstructions: " + task.getInstructions() + "\nComments: " + comments);
                filePreviewText.setVisible(true);
            }
        } else if (filePath.toLowerCase().endsWith(".pdf")) {
            filePreviewText.setText("PDF preview not supported. Please download the file.\nInstructions: " + task.getInstructions() + "\nComments: " + comments);
            filePreviewText.setVisible(true);
        }
    }

    private void displayMaterialContent(Material material) {
        clearPreview();
        String filePath = material.getFilePath();
        if (filePath == null || filePath.equals("No File")) {
            filePreviewText.setText("No file available.");
            filePreviewText.setVisible(true);
            return;
        }
        if (filePath.toLowerCase().endsWith(".txt")) {
            try {
                filePreviewText.setText(Files.readString(new File(filePath).toPath()));
                filePreviewText.setVisible(true);
            } catch (IOException ex) {
                filePreviewText.setText("Error reading file.");
                filePreviewText.setVisible(true);
            }
        } else if (filePath.toLowerCase().endsWith(".png") || filePath.toLowerCase().endsWith(".jpg") || filePath.toLowerCase().endsWith(".jpeg")) {
            try {
                Image image = new Image(new File(filePath).toURI().toString());
                filePreviewImage.setImage(image);
                filePreviewImage.setVisible(true);
            } catch (Exception ex) {
                filePreviewText.setText("Error loading image.");
                filePreviewText.setVisible(true);
            }
        } else if (filePath.toLowerCase().endsWith(".pdf")) {
            filePreviewText.setText("PDF preview not supported. Please download the file.");
            filePreviewText.setVisible(true);
        }
    }

    private void clearPreview() {
        filePreviewText.setText("");
        filePreviewText.setVisible(false);
        filePreviewImage.setImage(null);
        filePreviewImage.setVisible(false);
    }

    @FXML
    private void handleLogout() {
        logger.info("Logging out student_id: {}", studentId);
        stage.close();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/learning_management_system_project/fxmls/Login.fxml"));
            Stage loginStage = new Stage();
            loginStage.setScene(new Scene(loader.load(), 600, 400));
            loginStage.setTitle("Login");
            loginStage.show();
            logger.info("Opened login stage.");
        } catch (IOException ex) {
            logger.error("Failed to open login stage: {}", ex.getMessage(), ex);
            showAlert("Error", "Unable to open login stage: " + ex.getMessage());
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.initOwner(stage);
        alert.showAndWait();
    }

    public static class TaskSubmission {
        private final int taskId;
        private final SimpleStringProperty taskName;
        private final SimpleStringProperty taskType;
        private final SimpleStringProperty instructions;
        private final SimpleStringProperty status;
        private final SimpleStringProperty mark;
        private final SimpleStringProperty filePath;
        private final double weight;
        private final String fileContent;
        private final SimpleStringProperty comments;

        public TaskSubmission(int taskId, String taskName, String taskType, String instructions, String status,
                              String mark, String filePath, double weight, String fileContent, String comments) {
            this.taskId = taskId;
            this.taskName = new SimpleStringProperty(taskName);
            this.taskType = new SimpleStringProperty(taskType);
            this.instructions = new SimpleStringProperty(instructions != null ? instructions : "No instructions");
            this.status = new SimpleStringProperty(status);
            this.mark = new SimpleStringProperty(mark);
            this.filePath = new SimpleStringProperty(filePath);
            this.weight = weight;
            this.fileContent = fileContent;
            this.comments = new SimpleStringProperty(comments != null ? comments : "None");
        }

        public int getTaskId() { return taskId; }
        public String getTaskName() { return taskName.get(); }
        public String getTaskType() { return taskType.get(); }
        public String getInstructions() { return instructions.get(); }
        public String getStatus() { return status.get(); }
        public String getMark() { return mark.get(); }
        public String getFilePath() { return filePath.get(); }
        public double getWeight() { return weight; }
        public String getFileContent() { return fileContent; }
        public String getComments() { return comments.get(); }
    }

    public static class TaskProgress {
        private final int taskId;
        private final String taskName;
        private final String taskType;
        private final double weight;
        private final Double mark;
        private final double weightedScore;
        private final String comments;

        public TaskProgress(int taskId, String taskName, String taskType, double weight, Double mark, double weightedScore, String comments) {
            this.taskId = taskId;
            this.taskName = taskName;
            this.taskType = taskType;
            this.weight = weight;
            this.mark = mark;
            this.weightedScore = weightedScore;
            this.comments = comments;
        }
    }

    public static class Task {
        private final int taskId;
        private final String taskName;
        private final String taskType;
        private final String filePath;
        private final Timestamp dueDate;
        private final String instructions;
        private final double weight;

        public Task(int taskId, String taskName, String taskType, String filePath, Timestamp dueDate, String instructions, double weight) {
            this.taskId = taskId;
            this.taskName = taskName;
            this.taskType = taskType;
            this.filePath = filePath;
            this.dueDate = dueDate;
            this.instructions = instructions;
            this.weight = weight;
        }

        public int getTaskId() { return taskId; }
        public String getTaskName() { return taskName; }
        public String getTaskType() { return taskType; }
        public String getFilePath() { return filePath; }
        public Timestamp getDueDate() { return dueDate; }
        public String getInstructions() { return instructions; }
        public double getWeight() { return weight; }
    }

    public static class Announcement {
        private final int announcementId;
        private final String content;
        private final Timestamp postedDate;

        public Announcement(int announcementId, String content, Timestamp postedDate) {
            this.announcementId = announcementId;
            this.content = content;
            this.postedDate = postedDate;
        }

        public int getAnnouncementId() { return announcementId; }
        public String getContent() { return content; }
        public Timestamp getPostedDate() { return postedDate; }
    }

    public static class Material {
        private final int materialId;
        private final String materialName;
        private final String filePath;
        private final Timestamp uploadDate;

        public Material(int materialId, String materialName, String filePath, Timestamp uploadDate) {
            this.materialId = materialId;
            this.materialName = materialName;
            this.filePath = filePath;
            this.uploadDate = uploadDate;
        }

        public int getMaterialId() { return materialId; }
        public String getMaterialName() { return materialName; }
        public String getFilePath() { return filePath; }
        public Timestamp getUploadDate() { return uploadDate; }
    }

    private class StreamListCell extends ListCell<Object> {
        private final VBox vBox = new VBox(5);

        @Override
        protected void updateItem(Object item, boolean empty) {
            super.updateItem(item, empty);
            vBox.getChildren().clear();
            if (empty || item == null) {
                setGraphic(null);
                return;
            }
            if (item instanceof Announcement a) {
                vBox.setStyle("-fx-background-color: #e3f2fd; -fx-padding: 10; -fx-background-radius: 5; -fx-border-color: #e0e0e0; -fx-border-radius: 5;");
                Label content = new Label(a.getContent());
                content.setWrapText(true);
                content.setStyle("-fx-font-size: 12; -fx-text-fill: #333333;");
                Label date = new Label(a.getPostedDate().toLocalDateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
                date.setStyle("-fx-text-fill: #666666; ;-font-size: 12");
                vBox.getChildren().addAll(new Label("Announcement"), content, date);
            } else if (item instanceof Task t) {
                vBox.setStyle("-fx-background-color: #fff3e0; -fx-padding: 10; -fx-background-radius: 5; -fx-border-color: #e0e0e0; -fx-border-radius: 5;");
                Label name = new Label("Task: " + t.getTaskName());
                name.setStyle("-fx-font-weight: bold; -fx-font-size: 14; -fx-text-fill: #333333;");
                Label type = new Label("Type: " + t.getTaskType());
                type.setStyle("-fx-font-size: 12; -fx-text-fill: #333333;");
                Label instructions = new Label("Instructions: " + t.getInstructions());
                instructions.setStyle("-fx-font-size: 12; -fx-text-fill: #333333;");
                Label due = new Label("Due: " + (t.getDueDate() != null ? t.getDueDate().toLocalDateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) : "No due date"));
                due.setStyle("-fx-text-fill: #666666; -fx-font-size: 12;");
                vBox.getChildren().addAll(name, type, instructions, due);
            } else if (item instanceof Material m) {
                vBox.setStyle("-fx-background-color: #e8f5e9; -fx-padding: 10; -fx-background-radius: 5; -fx-border-color: #e0e0e0; -fx-border-radius: 5;");
                Label name = new Label("Material: " + m.getMaterialName());
                name.setStyle("-fx-font-weight: bold; -fx-font-size: 14; -fx-text-fill: #333333;");
                Label uploaded = new Label("Uploaded: " + m.getUploadDate().toLocalDateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
                uploaded.setStyle("-fx-text-fill: #666666; -fx-font-size: 12;");
                vBox.getChildren().addAll(name, uploaded);
            }
            setGraphic(vBox);
        }
    }

    private class TaskListCell extends ListCell<TaskSubmission> {
        private final HBox hBox = new HBox(10);
        private final Label taskNameLabel = new Label();
        private final Label statusLabel = new Label();
        private final Label markLabel = new Label();
        private final Label weightLabel = new Label();
        private final Button uploadButton = new Button("Upload");
        private final Button submitButton = new Button("Submit");
        private final Button downloadButton = new Button("Download");

        public TaskListCell() {
            taskNameLabel.setPrefWidth(200);
            taskNameLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14; -fx-text-fill: #333333;");
            statusLabel.setPrefWidth(150);
            statusLabel.setStyle("-fx-font-size: 12; -fx-text-fill: #666666;");
            markLabel.setPrefWidth(100);
            markLabel.setStyle("-fx-font-size: 12; -fx-text-fill: #666666;");
            weightLabel.setPrefWidth(100);
            weightLabel.setStyle("-fx-font-size: 12; -fx-text-fill: #666666;");

            uploadButton.setStyle("-fx-background-color: #0078d7; -fx-text-fill: white; -fx-background-radius: 4; -fx-padding: 5;");
            submitButton.setStyle("-fx-background-color: #0078d7; -fx-text-fill: white; -fx-background-radius: 4; -fx-padding: 5;");
            downloadButton.setStyle("-fx-background-color: #0078d7; -fx-text-fill: white; -fx-background-radius: 4; -fx-padding: 5;");

            hBox.getChildren().addAll(taskNameLabel, statusLabel, markLabel, weightLabel, uploadButton, submitButton, downloadButton);
            hBox.setStyle("-fx-background-color: #ffffff; -fx-padding: 10; -fx-background-radius: 5; -fx-border-color: #e0e0e0; -fx-border-radius: 5;");

            uploadButton.setOnAction(e -> {
                TaskSubmission task = getItem();
                if (task != null) handleUpload(task.getTaskId(), task.getTaskName());
            });
            submitButton.setOnAction(e -> {
                TaskSubmission task = getItem();
                if (task != null) handleSubmit(task.getTaskId(), task.getTaskName());
            });
            downloadButton.setOnAction(e -> {
                TaskSubmission task = getItem();
                if (task != null) handleTaskDownload(task);
            });

            hBox.setOnMouseEntered(e -> {
                ScaleTransition scale = new ScaleTransition(Duration.millis(200), hBox);
                scale.setToX(1.02);
                scale.setToY(1.02);
                scale.play();
            });
            hBox.setOnMouseExited(e -> {
                ScaleTransition scale = new ScaleTransition(Duration.millis(200), hBox);
                scale.setToX(1.0);
                scale.setToY(1.0);
                scale.play();
            });
        }

        @Override
        protected void updateItem(TaskSubmission item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setGraphic(null);
                return;
            }
            taskNameLabel.setText(item.getTaskName() + " (" + item.getTaskType() + ")");
            taskNameLabel.setTooltip(new Tooltip(item.getInstructions()));
            statusLabel.setText(item.getStatus());
            switch (item.getStatus()) {
                case "Not Submitted":
                    statusLabel.setStyle("-fx-text-fill: #d32f2f; -fx-font-size: 12;");
                    break;
                case "Submitted":
                    statusLabel.setStyle("-fx-text-fill: #388e3c; -fx-font-size: 12;");
                    break;
                case "Graded":
                    statusLabel.setStyle("-fx-text-fill: #0288d1; -fx-font-size: 12;");
                    break;
                default:
                    statusLabel.setStyle("-fx-text-fill: #666666; -fx-font-size: 12;");
            }
            markLabel.setText(item.getMark());
            weightLabel.setText(String.format("%.2f%%", item.getWeight() * 100));
            submitButton.setDisable(item.getStatus().startsWith("Submitted") || item.getFilePath().equals("No File"));
            downloadButton.setDisable(item.getFilePath().equals("No File"));
            setGraphic(hBox);
        }
    }

    private class MaterialListCell extends ListCell<Material> {
        private final HBox hBox = new HBox(10);
        private final Label nameLabel = new Label();
        private final Label dateLabel = new Label();
        private final Button downloadButton = new Button("Download");

        public MaterialListCell() {
            nameLabel.setPrefWidth(400);
            nameLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14; -fx-text-fill: #333333;");
            dateLabel.setPrefWidth(200);
            dateLabel.setStyle("-fx-text-fill: #666666; -fx-font-size: 12;");
            downloadButton.setStyle("-fx-background-color: #0078d7; -fx-text-fill: white; -fx-background-radius: 4; -fx-padding: 5;");
            hBox.getChildren().addAll(nameLabel, dateLabel, downloadButton);
            hBox.setStyle("-fx-background-color: #ffffff; -fx-padding: 10; -fx-background-radius: 5; -fx-border-color: #e0e0e0; -fx-border-radius: 5;");

            downloadButton.setOnAction(e -> {
                Material material = getItem();
                if (material != null) handleMaterialDownload(material);
            });

            hBox.setOnMouseEntered(e -> {
                ScaleTransition scale = new ScaleTransition(Duration.millis(200), hBox);
                scale.setToX(1.02);
                scale.setToY(1.02);
                scale.play();
            });
            hBox.setOnMouseExited(e -> {
                ScaleTransition scale = new ScaleTransition(Duration.millis(200), hBox);
                scale.setToX(1.0);
                scale.setToY(1.0);
                scale.play();
            });
        }

        @Override
        protected void updateItem(Material item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setGraphic(null);
                return;
            }
            nameLabel.setText(item.getMaterialName());
            dateLabel.setText(item.getUploadDate().toLocalDateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
            downloadButton.setDisable(item.getFilePath() == null || item.getFilePath().equals("No File"));
            setGraphic(hBox);
        }
    }
}