package com.example.learning_management_system_project;

import com.example.learning_management_system_project.DB.DBConnection;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AddFacultyController {

    @FXML private TextField facultyNameField;
    @FXML private Button addFacultyButton;
    @FXML private TableView<Faculty> facultyTable;
    @FXML private TableColumn<Faculty, String> facultyNameColumn;
    @FXML private TableColumn<Faculty, Void> actionColumn;

    private final ObservableList<Faculty> facultyList = FXCollections.observableArrayList();
    private Faculty selectedFaculty = null;
    private Stage stage;

    @FXML
    public void initialize() {
        setupTableColumns();
        facultyTable.setItems(facultyList);
        loadFaculties();
    }

    private void setupTableColumns() {
        facultyNameColumn.setCellValueFactory(new PropertyValueFactory<>("facultyName"));
        actionColumn.setCellFactory(param -> new TableCell<>() {
            private final Button updateButton = new Button("Update");
            private final Button deleteButton = new Button("Delete");

            {
                updateButton.setStyle("-fx-background-color: #f1c40f; -fx-text-fill: white;");
                deleteButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
                updateButton.setOnAction(event -> handleUpdateFaculty(getTableView().getItems().get(getIndex())));
                deleteButton.setOnAction(event -> handleDeleteFaculty(getTableView().getItems().get(getIndex())));
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(new HBox(10, updateButton, deleteButton));
                }
            }
        });
    }

    @FXML
    private void handleAddFaculty() {
        String facultyName = facultyNameField.getText().trim();

        if (!validateFacultyName(facultyName)) {
            return;
        }

        Connection conn = null;
        PreparedStatement insertStmt = null;
        PreparedStatement checkStmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);

            if (isDuplicateFaculty(conn, facultyName)) {
                showAlert("Error", "A faculty with this name already exists.");
                conn.rollback();
                return;
            }

            if (selectedFaculty == null) {
                insertStmt = conn.prepareStatement("INSERT INTO faculties (faculty_name) VALUES (?)");
                insertStmt.setString(1, facultyName);
            } else {
                insertStmt = conn.prepareStatement("UPDATE faculties SET faculty_name = ? WHERE faculty_id = ?");
                insertStmt.setString(1, facultyName);
                insertStmt.setInt(2, selectedFaculty.getFacultyId());
            }

            int rowsAffected = insertStmt.executeUpdate();

            if (rowsAffected == 1) {
                conn.commit();
                showAlert("Success", selectedFaculty == null ? "Faculty added successfully!" : "Faculty updated successfully!");
                facultyNameField.clear();
                loadFaculties();
                selectedFaculty = null;
                addFacultyButton.setText("Add Faculty");
            } else {
                conn.rollback();
                showAlert("Error", "Operation failed.");
            }
        } catch (SQLException e) {
            handleDatabaseError(conn, e);
        } finally {
            closeResources(rs, checkStmt, insertStmt, conn);
        }
    }

    private boolean validateFacultyName(String facultyName) {
        if (facultyName.isEmpty()) {
            showAlert("Error", "Please enter a faculty name.");
            return false;
        }

        if (!facultyName.matches("[a-zA-Z\\s,.&-]+")) {
            showAlert("Error", "Faculty name can only contain letters, spaces, commas, periods, ampersands, or hyphens.");
            return false;
        }

        if (facultyName.length() > 255) {
            showAlert("Error", "Faculty name must be less than 255 characters.");
            return false;
        }

        return true;
    }

    private boolean isDuplicateFaculty(Connection conn, String facultyName) throws SQLException {
        try (PreparedStatement stmt = conn.prepareStatement(
                "SELECT COUNT(*) FROM faculties WHERE faculty_name = ? AND (? OR faculty_id != ?)")) {
            stmt.setString(1, facultyName);
            stmt.setBoolean(2, selectedFaculty == null);
            stmt.setInt(3, selectedFaculty == null ? 0 : selectedFaculty.getFacultyId());

            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    private void handleDatabaseError(Connection conn, SQLException e) {
        try {
            if (conn != null) conn.rollback();
        } catch (SQLException rollbackEx) {
            rollbackEx.printStackTrace();
        }

        String message = e.getSQLState() != null && e.getSQLState().startsWith("23")
                ? "Database constraint violation: " + e.getMessage()
                : "Database error: " + e.getMessage();

        showAlert("Error", message);
    }

    private void closeResources(ResultSet rs, PreparedStatement checkStmt,
                                PreparedStatement insertStmt, Connection conn) {
        try {
            if (rs != null) rs.close();
            if (checkStmt != null) checkStmt.close();
            if (insertStmt != null) insertStmt.close();
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void handleUpdateFaculty(Faculty faculty) {
        selectedFaculty = faculty;
        facultyNameField.setText(faculty.getFacultyName());
        addFacultyButton.setText("Update Faculty");
    }

    private void handleDeleteFaculty(Faculty faculty) {
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION,
                "Are you sure you want to delete " + faculty.getFacultyName() + "?",
                ButtonType.YES, ButtonType.NO);
        confirmation.setHeaderText(null);
        confirmation.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                try (Connection conn = DBConnection.getConnection();
                     PreparedStatement stmt = conn.prepareStatement(
                             "DELETE FROM faculties WHERE faculty_id = ?")) {
                    stmt.setInt(1, faculty.getFacultyId());
                    stmt.executeUpdate();
                    loadFaculties();
                    showAlert("Success", "Faculty deleted successfully!");
                } catch (SQLException e) {
                    String message = e.getSQLState() != null && e.getSQLState().equals("23503")
                            ? "Cannot delete faculty because it is referenced by one or more programs."
                            : "Failed to delete faculty: " + e.getMessage();
                    showAlert("Error", message);
                }
            }
        });
    }

    private void loadFaculties() {
        facultyList.clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT faculty_id, faculty_name FROM faculties ORDER BY faculty_name");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                facultyList.add(new Faculty(rs.getInt("faculty_id"), rs.getString("faculty_name")));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load faculties: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    // ============ Menu Bar Action Handlers ============

    @FXML
    private void handleHome(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/Home.fxml", "Home", event);
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        loadFaculties();
    }

    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/Login.fxml", "Login", event);
    }

    @FXML
    private void handleExit(ActionEvent event) {
        getStageFromEvent(event).close();
    }

    @FXML
    private void handleAddCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddCourse.fxml", "Add Course", event);
    }

    @FXML
    private void handleAssignCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AdminAssignCoursesView.fxml", "Assign Courses", event);
    }

    @FXML
    private void handleViewStudents(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewStudents.fxml", "View Students", event);
    }

    @FXML
    private void handleAddStudent(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddStudent.fxml", "Add Student", event);
    }

    @FXML
    private void handleViewStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "View Submissions", event);
    }

    @FXML
    private void handleStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Student Progress", event);
    }

    @FXML
    private void handleAddLecturer(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddLecturer.fxml", "Add Lecturer", event);
    }

    @FXML
    private void handleViewLecturers(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewLecturers.fxml", "View Lecturers", event);
    }

    @FXML
    private void handleViewFaculties(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewFaculties.fxml", "View Faculties", event);
    }

    @FXML
    private void handleProgressReport(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Report", event);
    }

    @FXML
    private void handleExportReport(ActionEvent event) {
        showAlert("Information", "Export Report functionality will be implemented soon.");
    }

    @FXML
    private void handleAbout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AboutUs.fxml", "About Us", event);
    }

    @FXML
    private void handleDocumentation(ActionEvent event) {
        showAlert("Information", "Documentation will be available soon.");
    }

    // ============ Utility Methods ============

    private void loadFXML(String fxmlPath, String title, ActionEvent event) throws IOException {
        URL resource = getClass().getResource(fxmlPath);
        if (resource == null) {
            throw new IllegalStateException("Cannot find FXML file at: " + fxmlPath);
        }
        Stage currentStage = (stage != null) ? stage : getStageFromEvent(event);
        FXMLLoader loader = new FXMLLoader(resource);
        currentStage.setScene(new Scene(loader.load(), 900, 500));
        currentStage.setTitle(title);
        currentStage.show();
    }

    private Stage getStageFromEvent(ActionEvent event) {
        return (Stage) ((Node) event.getSource()).getScene().getWindow();
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public static class Faculty {
        private final SimpleIntegerProperty facultyId;
        private final SimpleStringProperty facultyName;

        public Faculty(int id, String name) {
            this.facultyId = new SimpleIntegerProperty(id);
            this.facultyName = new SimpleStringProperty(name);
        }

        public int getFacultyId() {
            return facultyId.get();
        }

        public String getFacultyName() {
            return facultyName.get();
        }
    }
}