package com.example.learning_management_system_project;

import com.example.learning_management_system_project.DB.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ViewFacultiesController {

    @FXML private TableView<Faculty> facultyTable;
    @FXML private TableColumn<Faculty, String> facultyNameColumn;
    @FXML private Pagination pagination;

    private final ObservableList<Faculty> facultyList = FXCollections.observableArrayList();
    private static final int ITEMS_PER_PAGE = 5;
    private int totalItems;

    @FXML
    public void initialize() {
        facultyNameColumn.setCellValueFactory(new PropertyValueFactory<>("facultyName"));
        facultyTable.setItems(facultyList);
        setupPagination();
        loadTotalItems();
    }

    private void setupPagination() {
        pagination.setPageFactory(pageIndex -> {
            loadFaculties(pageIndex);
            return facultyTable;
        });
    }

    private void loadTotalItems() {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM faculties");
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                totalItems = rs.getInt(1);
                pagination.setPageCount((int) Math.ceil((double) totalItems / ITEMS_PER_PAGE));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load total faculties: " + e.getMessage());
        }
    }

    private void loadFaculties(int pageIndex) {
        facultyList.clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT faculty_name FROM faculties ORDER BY faculty_name LIMIT ? OFFSET ?"
             )) {
            stmt.setInt(1, ITEMS_PER_PAGE);
            stmt.setInt(2, pageIndex * ITEMS_PER_PAGE);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                facultyList.add(new Faculty(rs.getString("faculty_name")));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load faculties: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    public static class Faculty {
        private final String facultyName;

        public Faculty(String name) {
            this.facultyName = name;
        }

        public String getFacultyName() {
            return facultyName;
        }
    }

    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    private Stage getStageFromEvent(ActionEvent event) {
        Object source = event.getSource();
        if (source instanceof Node) {
            return (Stage) ((Node) source).getScene().getWindow();
        } else if (source instanceof MenuItem) {
            return (Stage) MenuItem.class.cast(source).getParentPopup().getOwnerWindow();
        }
        throw new IllegalStateException("Cannot determine Stage from event source.");
    }

    private void loadFXML(String fxmlPath, String title, ActionEvent event) throws IOException {
        URL resource = getClass().getResource(fxmlPath);
        if (resource == null) {
            throw new IllegalStateException("Cannot find FXML file at: " + fxmlPath);
        }
        Stage currentStage = (stage != null) ? stage : getStageFromEvent(event);
        FXMLLoader loader = new FXMLLoader(resource);
        Scene scene = new Scene(loader.load(), 900, 500);
        currentStage.setScene(scene);
        currentStage.setTitle(title);

        Object controller = loader.getController();
        if (controller != null) {
            try {
                Method setStageMethod = controller.getClass().getMethod("setStage", Stage.class);
                setStageMethod.invoke(controller, currentStage);
            } catch (NoSuchMethodException e) {
                // Optional stage setting method is absent — safe to ignore.
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        currentStage.show();
    }

    @FXML
    private void handleViewStudents(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/StudentDashboard.fxml", "Student Dashboard", event);
    }

    @FXML
    private void handleProgressReport(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleExportReport(ActionEvent event) {
        System.out.println("Export Report clicked.");
    }

    @FXML
    private void handleAbout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AboutUs.fxml", "About Us", event);
    }

    @FXML
    private void handleDocumentation(ActionEvent event) {
        System.out.println("Documentation clicked.");
    }

    @FXML
    private void handleViewCourses(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewCourses.fxml", "View Courses", event);
    }

    @FXML
    private void handleExit(ActionEvent event) {
        getStageFromEvent(event).close();
    }

    @FXML
    private void handleHome(ActionEvent event) throws IOException {
        URL resource = getClass().getResource("/com/example/learning_management_system_project/fxmls/Home.fxml");
        if (resource == null) {
            throw new IllegalStateException("Cannot find FXML file at: /com/example/learning_management_system_project/fxmls/Home.fxml");
        }
        FXMLLoader loader = new FXMLLoader(resource);
        Scene scene = ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow().getScene();
        scene.setRoot(loader.load());
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        System.out.println("Refresh clicked.");
    }

    @FXML
    private void handleAddCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddCourse.fxml", "Add Course", event);
    }

    @FXML
    private void handleAddStudent(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/StudentDashboard.fxml", "Student Dashboard", event);
    }

    @FXML
    private void handleViewStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleAssignCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AdminAssignCoursesView.fxml", "Assign Courses", event);
    }

    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/Login.fxml", "Login", event);
    }

    @FXML
    private void handleAddLecturer(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddLecturer.fxml", "Add Lecturer", event);
    }

    @FXML
    private void handleViewLecturers(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewLecturers.fxml", "View Lecturers", event);
    }

    @FXML
    private void handleAddFaculty(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddFaculty.fxml", "Add Faculty", event);
    }

    @FXML
    private void handleViewFaculties(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewFaculties.fxml", "View Faculties", event);
    }
}