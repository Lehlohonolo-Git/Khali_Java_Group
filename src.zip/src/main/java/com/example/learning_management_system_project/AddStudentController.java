package com.example.learning_management_system_project;

import com.example.learning_management_system_project.DB.DBConnection;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AddStudentController {

    @FXML private TextField studentNameField;
    @FXML private ComboBox<Program> programComboBox;
    @FXML private Button addStudentButton;
    @FXML private TableView<Student> studentTable;
    @FXML private TableColumn<Student, String> studentNameColumn;
    @FXML private TableColumn<Student, String> programColumn;
    @FXML private TableColumn<Student, Void> actionColumn;

    private final ObservableList<Student> studentList = FXCollections.observableArrayList();
    private final ObservableList<Program> programList = FXCollections.observableArrayList();
    private Student selectedStudent = null;

    @FXML
    public void initialize() {
        // Setup TableView columns
        studentNameColumn.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        programColumn.setCellValueFactory(new PropertyValueFactory<>("programName"));
        actionColumn.setCellFactory(param -> new TableCell<>() {
            private final Button updateButton = new Button("Update");
            private final Button deleteButton = new Button("Delete");

            {
                updateButton.setStyle("-fx-background-color: #f1c40f; -fx-text-fill: white; -fx-background-radius: 4; -fx-cursor: hand; -fx-effect: dropshadow(gaussian, #f1c40f, 8, 0.5, 0, 0);");
                deleteButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-background-radius: 4; -fx-cursor: hand; -fx-effect: dropshadow(gaussian, #e74c3c, 8, 0.5, 0, 0);");
                updateButton.setOnAction(event -> {
                    Student student = getTableView().getItems().get(getIndex());
                    handleUpdateStudent(student);
                });
                deleteButton.setOnAction(event -> {
                    Student student = getTableView().getItems().get(getIndex());
                    handleDeleteStudent(student);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox buttons = new HBox(10, updateButton, deleteButton);
                    setGraphic(buttons);
                }
            }
        });

        studentTable.setItems(studentList);

        // Setup ComboBox
        programComboBox.setItems(programList);
        programComboBox.setCellFactory(param -> new ListCell<>() {
            @Override
            protected void updateItem(Program program, boolean empty) {
                super.updateItem(program, empty);
                setText(empty || program == null ? null : program.getProgramName());
            }
        });
        programComboBox.setButtonCell(new ListCell<>() {
            @Override
            protected void updateItem(Program program, boolean empty) {
                super.updateItem(program, empty);
                setText(empty || program == null ? null : program.getProgramName());
            }
        });

        loadPrograms();
        loadStudents();
    }

    private void loadPrograms() {
        programList.clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT program_id, program_name FROM programs ORDER BY program_name");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                programList.add(new Program(rs.getInt("program_id"), rs.getString("program_name")));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load programs: " + e.getMessage());
        }
    }

    private void loadStudents() {
        studentList.clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT s.student_id, s.student_name, s.program_id, p.program_name " +
                             "FROM students s LEFT JOIN programs p ON s.program_id = p.program_id " +
                             "ORDER BY s.student_name")) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                studentList.add(new Student(
                        rs.getInt("student_id"),
                        rs.getString("student_name"),
                        rs.getInt("program_id"),
                        rs.getString("program_name")
                ));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load students: " + e.getMessage());
        }
    }

    @FXML
    private void handleAddStudent() {
        String studentName = studentNameField.getText().trim();
        Program selectedProgram = programComboBox.getSelectionModel().getSelectedItem();

        if (studentName.isEmpty() || selectedProgram == null) {
            showAlert("Error", "Please fill in all fields.");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            if (selectedStudent == null) {
                // Add new student
                PreparedStatement stmt = conn.prepareStatement(
                        "INSERT INTO students (student_name, program_id) VALUES (?, ?)");
                stmt.setString(1, studentName);
                stmt.setInt(2, selectedProgram.getProgramId());
                stmt.executeUpdate();
                showAlert("Success", "Student added successfully!");
            } else {
                // Update existing student
                PreparedStatement stmt = conn.prepareStatement(
                        "UPDATE students SET student_name = ?, program_id = ? WHERE student_id = ?");
                stmt.setString(1, studentName);
                stmt.setInt(2, selectedProgram.getProgramId());
                stmt.setInt(3, selectedStudent.getStudentId());
                stmt.executeUpdate();
                showAlert("Success", "Student updated successfully!");
                selectedStudent = null;
                addStudentButton.setText("Add Student");
            }
            clearForm();
            loadStudents();
        } catch (SQLException e) {
            showAlert("Error", "Failed to save student: " + e.getMessage());
        }
    }

    private void handleUpdateStudent(Student student) {
        selectedStudent = student;
        studentNameField.setText(student.getStudentName());
        programComboBox.getSelectionModel().select(programList.stream()
                .filter(p -> p.getProgramId() == student.getProgramId())
                .findFirst().orElse(null));
        addStudentButton.setText("Save Changes");
    }

    private void handleDeleteStudent(Student student) {
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION,
                "Are you sure you want to delete " + student.getStudentName() + "?",
                ButtonType.YES, ButtonType.NO);
        confirmation.setHeaderText(null);
        confirmation.showAndWait().ifPresent(response -> {
            if (response == ButtonType.YES) {
                try (Connection conn = DBConnection.getConnection();
                     PreparedStatement stmt = conn.prepareStatement("DELETE FROM students WHERE student_id = ?")) {
                    stmt.setInt(1, student.getStudentId());
                    stmt.executeUpdate();
                    loadStudents();
                    showAlert("Success", "Student deleted successfully!");
                } catch (SQLException e) {
                    showAlert("Error", "Failed to delete student: " + e.getMessage() +
                            ". This may be due to enrolled courses or submissions.");
                }
            }
        });
    }

    private void clearForm() {
        studentNameField.clear();
        programComboBox.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    public static class Student {
        private final SimpleIntegerProperty studentId;
        private final SimpleStringProperty studentName;
        private final SimpleIntegerProperty programId;
        private final SimpleStringProperty programName;

        public Student(int id, String name, int programId, String programName) {
            this.studentId = new SimpleIntegerProperty(id);
            this.studentName = new SimpleStringProperty(name);
            this.programId = new SimpleIntegerProperty(programId);
            this.programName = new SimpleStringProperty(programName);
        }

        public int getStudentId() {
            return studentId.get();
        }

        public String getStudentName() {
            return studentName.get();
        }

        public int getProgramId() {
            return programId.get();
        }

        public String getProgramName() {
            return programName.get();
        }
    }

    public static class Program {
        private final SimpleIntegerProperty programId;
        private final SimpleStringProperty programName;

        public Program(int id, String name) {
            this.programId = new SimpleIntegerProperty(id);
            this.programName = new SimpleStringProperty(name);
        }

        public int getProgramId() {
            return programId.get();
        }

        public String getProgramName() {
            return programName.get();
        }
    }

    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    private Stage getStageFromEvent(ActionEvent event) {
        Object source = event.getSource();
        if (source instanceof Node) {
            return (Stage) ((Node) source).getScene().getWindow();
        } else if (source instanceof MenuItem) {
            return (Stage) MenuItem.class.cast(source).getParentPopup().getOwnerWindow();
        }
        throw new IllegalStateException("Cannot determine Stage from event source.");
    }

    private void loadFXML(String fxmlPath, String title, ActionEvent event) throws IOException {
        URL resource = getClass().getResource(fxmlPath);
        if (resource == null) {
            throw new IllegalStateException("Cannot find FXML file at: " + fxmlPath);
        }
        Stage currentStage = (stage != null) ? stage : getStageFromEvent(event);
        FXMLLoader loader = new FXMLLoader(resource);
        Scene scene = new Scene(loader.load(), 900, 500);
        currentStage.setScene(scene);
        currentStage.setTitle(title);

        Object controller = loader.getController();
        if (controller != null) {
            try {
                Method setStageMethod = controller.getClass().getMethod("setStage", Stage.class);
                setStageMethod.invoke(controller, currentStage);
            } catch (NoSuchMethodException e) {
                // Optional stage setting method is absent — safe to ignore.
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        currentStage.show();
    }

    @FXML
    private void handleViewStudents(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewStudents.fxml", "View Students", event);
    }

    @FXML
    private void handleProgressReport(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleExportReport(ActionEvent event) {
        System.out.println("Export Report clicked.");
    }

    @FXML
    private void handleAbout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AboutUs.fxml", "About Us", event);
    }

    @FXML
    private void handleDocumentation(ActionEvent event) {
        System.out.println("Documentation clicked.");
    }

    @FXML
    private void handleViewCourses(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewCourses.fxml", "View Courses", event);
    }

    @FXML
    private void handleExit(ActionEvent event) {
        getStageFromEvent(event).close();
    }

    @FXML
    private void handleHome(ActionEvent event) throws IOException {
        URL resource = getClass().getResource("/com/example/learning_management_system_project/fxmls/Home.fxml");
        if (resource == null) {
            throw new IllegalStateException("Cannot find FXML file at: /com/example/learning_management_system_project/fxmls/Home.fxml");
        }
        FXMLLoader loader = new FXMLLoader(resource);
        Scene scene = ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow().getScene();
        scene.setRoot(loader.load());
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        loadStudents();
    }

    @FXML
    private void handleAddCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddCourse.fxml", "Add Course", event);
    }

    @FXML
    private void handleAddStudent(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddStudent.fxml", "Add Student", event);
    }

    @FXML
    private void handleViewStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleAssignCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AdminAssignCoursesView.fxml", "Assign Courses", event);
    }

    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/Login.fxml", "Login", event);
    }

    @FXML
    private void handleAddLecturer(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddLecturer.fxml", "Add Lecturer", event);
    }

    @FXML
    private void handleViewLecturers(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewLecturers.fxml", "View Lecturers", event);
    }

    @FXML
    private void handleAddFaculty(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddFaculty.fxml", "Add Faculty", event);
    }

    @FXML
    private void handleViewFaculties(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewFaculties.fxml", "View Faculties", event);
    }
}