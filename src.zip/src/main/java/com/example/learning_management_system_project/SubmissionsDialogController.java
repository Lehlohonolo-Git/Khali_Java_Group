package com.example.learning_management_system_project;

import com.example.learning_management_system_project.DB.DBConnection;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;

public class SubmissionsDialogController {
    private static final Logger logger = LoggerFactory.getLogger(SubmissionsDialogController.class);

    @FXML private ListView<Submission> submissionList; // Matches fx:id="submissionList" in FXML
    @FXML private Label taskLabel;
    @FXML private TextArea filePreviewText;
    @FXML private ImageView filePreviewImage;
    @FXML private TextField markField;
    @FXML private TextArea commentsField;
    @FXML private Button saveMarkButton;
    @FXML private Button backButton;
    @FXML private Button downloadButton;

    private final ObservableList<Submission> submissions = FXCollections.observableArrayList();
    private int courseId;
    private int taskId;
    private int lecturerId;
    private Stage stage;
    private Runnable onMarkAssigned;

    public void setCourseId(int courseId) {
        this.courseId = courseId;
        logger.debug("Set courseId to {}", courseId);
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
        logger.debug("Set taskId to {}", taskId);
    }

    public void setLecturerId(int lecturerId) {
        this.lecturerId = lecturerId;
        logger.debug("Set lecturerId to {}", lecturerId);
        loadSubmissions();
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void setOnMarkAssigned(Runnable onMarkAssigned) {
        this.onMarkAssigned = onMarkAssigned;
    }

    @FXML
    public void initialize() {
        if (submissionList == null) {
            logger.error("submissionList is null in initialize()");
            throw new IllegalStateException("submissionList is not initialized. Check FXML binding.");
        }
        submissionList.setItems(submissions);
        submissionList.setCellFactory(param -> new SubmissionListCell());

        submissionList.getSelectionModel().selectedItemProperty().addListener((obs, old, newSelection) -> {
            if (newSelection != null) {
                displaySubmissionContent(newSelection);
                markField.setText(newSelection.getMark());
                commentsField.setText(newSelection.getComments() != null ? newSelection.getComments() : "");
            } else {
                clearPreview();
                markField.clear();
                commentsField.clear();
            }
        });
    }

    private void loadSubmissions() {
        submissions.clear();
        String query = """
            SELECT
                s.submission_id,
                s.student_id,
                COALESCE(st.student_name, 'Unknown') AS student_name,
                s.task_id,
                t.task_type,
                s.file_path,
                s.file_content,
                s.mark,
                COALESCE(s.submission_date, CURRENT_TIMESTAMP) AS submission_date,
                s.submission_status,
                s.comments
            FROM submissions s
            JOIN tasks t ON s.task_id = t.task_id
            JOIN students st ON s.student_id = st.student_id
            WHERE s.course_id = ?
              AND s.task_id = ?
              AND s.lecturer_id = ?
              AND s.submission_status = 'Submitted'
        """;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, courseId);
            stmt.setInt(2, taskId);
            stmt.setInt(3, lecturerId);
            ResultSet rs = stmt.executeQuery();
            int count = 0;
            while (rs.next()) {
                count++;
                int submissionId = rs.getInt("submission_id");
                int studentId = rs.getInt("student_id");
                String studentName = rs.getString("student_name");
                String taskType = rs.getString("task_type");
                String filePath = rs.getString("file_path");
                String fileContent = rs.getString("file_content");
                Double mark = rs.getObject("mark") != null ? rs.getDouble("mark") : null;
                Timestamp submissionDate = rs.getTimestamp("submission_date");
                String comments = rs.getString("comments");

                String status = mark != null ? String.format("Marked: %.2f", mark) : "Submitted";
                String markText = mark != null ? String.format("%.2f", mark) : "-";
                String filePathText = filePath != null && !filePath.isEmpty() ? filePath : "No File";
                String fileContentText = fileContent != null ? fileContent : "";
                String submissionDateText = submissionDate != null ?
                        submissionDate.toLocalDateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")) : "Unknown";

                submissions.add(new Submission(
                        submissionId, studentId, studentName, taskId, taskType, status, markText,
                        filePathText, fileContentText, submissionDateText, comments));
                logger.debug("Loaded submission: submission_id={}, student={}, task_type={}, status={}, mark={}",
                        submissionId, studentName, taskType, status, markText);
            }
            logger.info("Loaded {} submissions for course_id: {}, task_id: {}, lecturer_id: {}",
                    count, courseId, taskId, lecturerId);
            taskLabel.setText("Submissions (" + count + ")");
            if (count == 0) {
                showAlert("No Submissions", "No submitted assignments for this task.");
            }
        } catch (SQLException e) {
            logger.error("Failed to load submissions for course_id: {}, task_id: {}, lecturer_id: {}: {}",
                    courseId, taskId, lecturerId, e.getMessage(), e);
            showAlert("Error", "Unable to load submissions: " + e.getMessage());
        }
    }

    private void displaySubmissionContent(Submission submission) {
        clearPreview();
        String filePath = submission.getFilePath();
        if (filePath == null || filePath.equals("No File")) {
            filePreviewText.setText("No file submitted.");
            filePreviewText.setVisible(true);
            return;
        }
        if (filePath.toLowerCase().endsWith(".txt")) {
            filePreviewText.setText(submission.getFileContent());
            filePreviewText.setVisible(true);
        } else if (filePath.toLowerCase().endsWith(".png") || filePath.toLowerCase().endsWith(".jpg") || filePath.toLowerCase().endsWith(".jpeg")) {
            try {
                Image image = new Image(new File(filePath).toURI().toString());
                filePreviewImage.setImage(image);
                filePreviewImage.setVisible(true);
            } catch (Exception ex) {
                filePreviewText.setText("Error loading image.");
                filePreviewText.setVisible(true);
            }
        } else if (filePath.toLowerCase().endsWith(".pdf")) {
            filePreviewText.setText("PDF preview not supported. Please download the file.");
            filePreviewText.setVisible(true);
        }
    }

    private void clearPreview() {
        filePreviewText.setText("");
        filePreviewText.setVisible(false);
        filePreviewImage.setImage(null);
        filePreviewImage.setVisible(false);
    }

    private void assignMark(Submission submission) {
        String markText = markField.getText();
        String comments = commentsField.getText();
        try {
            double mark = Double.parseDouble(markText);
            if (mark < 0 || mark > 100) {
                showAlert("Invalid Mark", "Mark must be between 0 and 100.");
                return;
            }
            String query = """
                UPDATE submissions
                SET mark = ?, submission_status = 'Graded', comments = ?
                WHERE submission_id = ?
            """;
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setDouble(1, mark);
                stmt.setString(2, comments.isEmpty() ? null : comments);
                stmt.setInt(3, submission.getSubmissionId());
                stmt.executeUpdate();
                showAlert("Success", "Mark assigned successfully.");
                logger.info("Assigned mark {} for submission_id: {}", mark, submission.getSubmissionId());
                loadSubmissions();
                if (onMarkAssigned != null) {
                    onMarkAssigned.run();
                }
            }
        } catch (NumberFormatException e) {
            showAlert("Invalid Mark", "Please enter a valid number for the mark.");
            logger.warn("Invalid mark input for submission_id: {}: {}", submission.getSubmissionId(), markText);
        } catch (SQLException e) {
            logger.error("Failed to assign mark for submission_id {}: {}", submission.getSubmissionId(), e.getMessage(), e);
            showAlert("Error", "Failed to assign mark: " + e.getMessage());
        }
    }

    @FXML
    private void handleDownload() {
        Submission selected = submissionList.getSelectionModel().getSelectedItem();
        if (selected == null || selected.getFilePath().equals("No File")) {
            showAlert("No File", "No file available for download.");
            return;
        }
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Submission File");
        fileChooser.setInitialFileName(new File(selected.getFilePath()).getName());
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Files", "*.*"),
                new FileChooser.ExtensionFilter("Text Files", "*.txt"),
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"),
                new FileChooser.ExtensionFilter("PDF Files", "*.pdf")
        );
        File destination = fileChooser.showSaveDialog(stage);
        if (destination != null) {
            try {
                Files.copy(new File(selected.getFilePath()).toPath(), destination.toPath());
                showAlert("Success", "File downloaded to: " + destination.getAbsolutePath());
                logger.info("Downloaded submission file {} to {}", selected.getFilePath(), destination.getAbsolutePath());
            } catch (IOException e) {
                logger.error("Failed to download submission file {}: {}", selected.getFilePath(), e.getMessage(), e);
                showAlert("Error", "Download failed: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleSaveMark(ActionEvent actionEvent) {
        Submission selected = submissionList.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("No Selection", "Please select a submission to mark.");
            return;
        }
        assignMark(selected);
    }

    @FXML
    private void handleBack(ActionEvent actionEvent) {
        if (stage != null) {
            stage.close();
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        if (stage != null) {
            alert.initOwner(stage);
        }
        alert.showAndWait();
    }

    public static class Submission {
        private final int submissionId;
        private final int studentId;
        private final SimpleStringProperty studentName;
        private final int taskId;
        private final SimpleStringProperty taskType;
        private final SimpleStringProperty status;
        private final SimpleStringProperty mark;
        private final SimpleStringProperty filePath;
        private final SimpleStringProperty fileContent;
        private final SimpleStringProperty submissionDate;
        private final SimpleStringProperty comments;

        public Submission(int submissionId, int studentId, String studentName, int taskId, String taskType,
                          String status, String mark, String filePath, String fileContent, String submissionDate, String comments) {
            this.submissionId = submissionId;
            this.studentId = studentId;
            this.studentName = new SimpleStringProperty(studentName);
            this.taskId = taskId;
            this.taskType = new SimpleStringProperty(taskType);
            this.status = new SimpleStringProperty(status);
            this.mark = new SimpleStringProperty(mark);
            this.filePath = new SimpleStringProperty(filePath);
            this.fileContent = new SimpleStringProperty(fileContent);
            this.submissionDate = new SimpleStringProperty(submissionDate);
            this.comments = new SimpleStringProperty(comments);
        }

        public int getSubmissionId() { return submissionId; }
        public int getStudentId() { return studentId; }
        public String getStudentName() { return studentName.get(); }
        public int getTaskId() { return taskId; }
        public String getTaskType() { return taskType.get(); }
        public String getStatus() { return status.get(); }
        public String getMark() { return mark.get(); }
        public String getFilePath() { return filePath.get(); }
        public String getFileContent() { return fileContent.get(); }
        public String getSubmissionDate() { return submissionDate.get(); }
        public String getComments() { return comments.get(); }
    }

    private class SubmissionListCell extends ListCell<Submission> {
        private final HBox hBox = new HBox(10);
        private final Label studentLabel = new Label();
        private final Label typeLabel = new Label();
        private final Label statusLabel = new Label();
        private final Label markLabel = new Label();
        private final Label dateLabel = new Label();

        public SubmissionListCell() {
            studentLabel.setPrefWidth(150);
            studentLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14; -fx-text-fill: #333333;");
            typeLabel.setPrefWidth(100);
            typeLabel.setStyle("-fx-font-size: 12; -fx-text-fill: #666666;");
            statusLabel.setPrefWidth(150);
            statusLabel.setStyle("-fx-font-size: 12; -fx-text-fill: #666666;");
            markLabel.setPrefWidth(100);
            markLabel.setStyle("-fx-font-size: 12; -fx-text-fill: #666666;");
            dateLabel.setPrefWidth(150);
            dateLabel.setStyle("-fx-font-size: 12; -fx-text-fill: #666666;");
            hBox.getChildren().addAll(studentLabel, typeLabel, statusLabel, markLabel, dateLabel);
            hBox.setStyle("-fx-background-color: #ffffff; -fx-padding: 10; -fx-background-radius: 5; -fx-border-color: #e0e0e0; -fx-border-radius: 5;");
        }

        @Override
        protected void updateItem(Submission item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setGraphic(null);
                return;
            }
            studentLabel.setText(item.getStudentName());
            typeLabel.setText(item.getTaskType());
            statusLabel.setText(item.getStatus());
            statusLabel.setStyle(item.getStatus().startsWith("Marked") ?
                    "-fx-text-fill: #0288d1; -fx-font-size: 12;" : "-fx-text-fill: #388e3c; -fx-font-size: 12;");
            markLabel.setText(item.getMark());
            dateLabel.setText(item.getSubmissionDate());
            setGraphic(hBox);
        }
    }
}