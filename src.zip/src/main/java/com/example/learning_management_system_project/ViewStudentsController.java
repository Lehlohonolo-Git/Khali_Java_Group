package com.example.learning_management_system_project;

import com.example.learning_management_system_project.DB.DBConnection;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ViewStudentsController {

    @FXML private TableView<Student> studentTable;
    @FXML private TableColumn<Student, String> studentNameColumn;
    @FXML private TableColumn<Student, String> programColumn;

    private final ObservableList<Student> studentList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        studentNameColumn.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        programColumn.setCellValueFactory(new PropertyValueFactory<>("programName"));

        studentTable.setItems(studentList);
        loadStudents();
    }

    private void loadStudents() {
        studentList.clear();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT s.student_id, s.student_name, s.program_id, p.program_name " +
                             "FROM students s LEFT JOIN programs p ON s.program_id = p.program_id " +
                             "ORDER BY s.student_name")) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                studentList.add(new Student(
                        rs.getInt("student_id"),
                        rs.getString("student_name"),
                        rs.getInt("program_id"),
                        rs.getString("program_name")
                ));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load students: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    public static class Student {
        private final SimpleIntegerProperty studentId;
        private final SimpleStringProperty studentName;
        private final SimpleIntegerProperty programId;
        private final SimpleStringProperty programName;

        public Student(int id, String name, int programId, String programName) {
            this.studentId = new SimpleIntegerProperty(id);
            this.studentName = new SimpleStringProperty(name);
            this.programId = new SimpleIntegerProperty(programId);
            this.programName = new SimpleStringProperty(programName);
        }

        public int getStudentId() {
            return studentId.get();
        }

        public String getStudentName() {
            return studentName.get();
        }

        public int getProgramId() {
            return programId.get();
        }

        public String getProgramName() {
            return programName.get();
        }
    }

    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    private Stage getStageFromEvent(ActionEvent event) {
        Object source = event.getSource();
        if (source instanceof Node) {
            return (Stage) ((Node) source).getScene().getWindow();
        } else if (source instanceof MenuItem) {
            return (Stage) MenuItem.class.cast(source).getParentPopup().getOwnerWindow();
        }
        throw new IllegalStateException("Cannot determine Stage from event source.");
    }

    private void loadFXML(String fxmlPath, String title, ActionEvent event) throws IOException {
        URL resource = getClass().getResource(fxmlPath);
        if (resource == null) {
            throw new IllegalStateException("Cannot find FXML file at: " + fxmlPath);
        }
        Stage currentStage = (stage != null) ? stage : getStageFromEvent(event);
        FXMLLoader loader = new FXMLLoader(resource);
        Scene scene = new Scene(loader.load(), 900, 500);
        currentStage.setScene(scene);
        currentStage.setTitle(title);

        Object controller = loader.getController();
        if (controller != null) {
            try {
                Method setStageMethod = controller.getClass().getMethod("setStage", Stage.class);
                setStageMethod.invoke(controller, currentStage);
            } catch (NoSuchMethodException e) {
                // Optional stage setting method is absent — safe to ignore.
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        currentStage.show();
    }

    @FXML
    private void handleViewStudents(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewStudents.fxml", "View Students", event);
    }

    @FXML
    private void handleProgressReport(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleExportReport(ActionEvent event) {
        System.out.println("Export Report clicked.");
    }

    @FXML
    private void handleAbout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AboutUs.fxml", "About Us", event);
    }

    @FXML
    private void handleDocumentation(ActionEvent event) {
        System.out.println("Documentation clicked.");
    }

    @FXML
    private void handleViewCourses(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewCourses.fxml", "View Courses", event);
    }

    @FXML
    private void handleExit(ActionEvent event) {
        getStageFromEvent(event).close();
    }

    @FXML
    private void handleHome(ActionEvent event) throws IOException {
        URL resource = getClass().getResource("/com/example/learning_management_system_project/fxmls/Home.fxml");
        if (resource == null) {
            throw new IllegalStateException("Cannot find FXML file at: /com/example/learning_management_system_project/fxmls/Home.fxml");
        }
        FXMLLoader loader = new FXMLLoader(resource);
        Scene scene = ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow().getScene();
        scene.setRoot(loader.load());
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        loadStudents();
    }

    @FXML
    private void handleAddCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddCourse.fxml", "Add Course", event);
    }

    @FXML
    private void handleAddStudent(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddStudent.fxml", "Add Student", event);
    }

    @FXML
    private void handleViewStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleStudentProgress(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/submissionsDialog.fxml", "Submissions Dialog", event);
    }

    @FXML
    private void handleAssignCourse(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AdminAssignCoursesView.fxml", "Assign Courses", event);
    }

    @FXML
    private void handleLogout(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/Login.fxml", "Login", event);
    }

    @FXML
    private void handleAddLecturer(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddLecturer.fxml", "Add Lecturer", event);
    }

    @FXML
    private void handleViewLecturers(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewLecturers.fxml", "View Lecturers", event);
    }

    @FXML
    private void handleAddFaculty(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/AddFaculty.fxml", "Add Faculty", event);
    }

    @FXML
    private void handleViewFaculties(ActionEvent event) throws IOException {
        loadFXML("/com/example/learning_management_system_project/fxmls/ViewFaculties.fxml", "View Faculties", event);
    }
}